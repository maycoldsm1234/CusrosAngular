import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";


@Injectable({
  providedIn: 'root'
})
export class TimeService {
  private httpOptions = {};

  constructor(
    private http: HttpClient
) {
    this.httpOptions = {
        headers: new HttpHeaders({
            Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
        })
    };
}

  add(params) {

    return this.http.post<any>(`${environment.apiUrl}time/add`, params, this.httpOptions);
  }

  getTime() {
    return this.http.get<any>(`${environment.apiUrl}time/get`);
  }

  update(params) {
    return this.http.post<any>(`${environment.apiUrl}time/update`, params, this.httpOptions);
  }

  delete(idTime) {
    return this.http.post<any>(`${environment.apiUrl}time/delete`, {idTime}, this.httpOptions);
}

}
