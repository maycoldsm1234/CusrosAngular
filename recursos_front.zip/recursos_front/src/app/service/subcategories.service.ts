import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: "root",
})
export class SubcategoriesService {
  private headers = {
    headers: new HttpHeaders({
      Authorization: "Bearer " + localStorage.getItem("resourceToken"),
    }),
  };
  constructor(private http: HttpClient) {}

  getAll() {
    return this.http.get<any[]>(`${environment.apiUrl}subcategory/get/all`);
  }

  saveSubcategory(params) {
    let method = (params.idSubcategory) ? 'update' : 'add';
    return this.http.post(`${environment.apiUrl}subcategory/`+method, params, this.headers);
  }

  getsubcategoryBycategory(params){

    return this.http.post(`${environment.apiUrl}subcategory/getByCategoty`, params, this.headers);

  }

  deleteSubcategory(params){

    return this.http.post(`${environment.apiUrl}subcategory/delete`, params, this.headers);

  }

  getByCategory(params) {
    return this.http.post(`${environment.apiUrl}subcategory/getByCategoty`, params, this.headers);
  }
}
