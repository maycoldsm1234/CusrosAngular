import { Injectable } from "@angular/core";
import { HttpClient, HttpHeaders } from "@angular/common/http";
import { environment } from "src/environments/environment";

@Injectable({
  providedIn: "root",
})
export class AreasService {
  headers = {
    headers: new HttpHeaders({
      Authorization: "Bearer " + localStorage.getItem("resourceToken"),
    }),
  };
  constructor(private http: HttpClient) {}

  getAll() {
    return this.http.get<any[]>(`${environment.apiUrl}area/get/all`);
  }

  saveArea(params) {
    let method = (params.idIntArea) ? 'update' : 'add';
    return this.http.post(`${environment.apiUrl}area/`+method, params, this.headers);
  }

  deleteArea(params){
    return this.http.post(`${environment.apiUrl}area/delete`, params, this.headers);
  }

  getInfoArea(params){
    return this.http.post(`${environment.apiUrl}user/getArea`, params, this.headers);
  }
}
