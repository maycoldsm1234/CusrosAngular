import { environment } from './../../environments/environment';
import { TokenService } from './utils/token.service';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class CategoryService {
    private headers = {
        headers: new HttpHeaders({
            Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
        })
    };

    constructor(private http: HttpClient, private token: TokenService) {
    }

    getCategory() {
        return this.http.get<any[]>(`${environment.apiUrl}categorie/get`);
    }

    save(params) {
        let action = 'save';
        if(params.idCategory){
            action = 'update';
        }
        return this.http.post<any[]>(`${environment.apiUrl}category/${action}`, params, this.headers);
    }

    getAll(params){
        return this.http.post<any[]>(`${environment.apiUrl}category/get/all`, params);
    }
    
    getCategoryByUser(params) {
        params = this.token.structureParams(params);
        return this.http.post(`${environment.apiUrl}user/categories/get`, params, this.headers);
    }

    delete(params){
        return this.http.post<any[]>(`${environment.apiUrl}category/delete`,params);
    }

    setCategory(params) {
        return this.http.post<any[]>(`${environment.apiUrl}request/category/update`, params, this.headers);
    }

    getcategoryByAreaUser(params){
        return this.http.post<any[]>(`${environment.apiUrl}category/getbyArea`,params);
    }

    getCategoryByUserArea(params) {
        return this.http.post(`${environment.apiUrl}user/categories/area/get`, params, this.headers);
    }

    getSubcategoryByCategory(params) {        
        return this.http.post(`${environment.apiUrl}subcategory/getByCategoty`, params, this.headers);
    }
}