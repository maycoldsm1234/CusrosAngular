import { environment } from './../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class InstructiveService {
    private headers = {
        headers: new HttpHeaders({
            Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
        })
    };
    constructor(
        private http: HttpClient
    ) {}

    saveInstructive(params) {
        return this.http.post(`${environment.apiUrl}instructive/add`, params, this.headers);
    }

    downloadInstructive(key) {
        let params = {
            key: key
        }
        this.http.post(`${environment.apiUrl}instructive/getpath`, params, this.headers).subscribe(
            (response: any) => {
                const path = response.data.path_file;
                const url = `${environment.apiUrl}instructive/download/?path=${path}`;
                window.open(url, '_blank');
            }
        );
    }
}