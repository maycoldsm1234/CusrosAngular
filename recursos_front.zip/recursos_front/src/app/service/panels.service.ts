import { TokenService } from 'src/app/service/utils/token.service';
import { environment } from 'src/environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';

@Injectable({
    providedIn: 'root'
})
export class PanelsService {
    constructor(
        private http: HttpClient,
        private tokenService: TokenService
    ) {}

    getPanelsData(params: FormData) {
        return this.http.post<any>(`${environment.apiUrl}request/get/filter`, params);
    }

    getManagementsData(params: FormData) {
        return this.http.post<any[]>(`${environment.apiUrl}request/get/management`, params);
    }
}
