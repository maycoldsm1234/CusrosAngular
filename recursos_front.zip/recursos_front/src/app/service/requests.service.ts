import { environment } from './../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";
import { SaveRequest } from '../model/requests.model';

@Injectable({
    providedIn: 'root'
})
export class RequestsService {
    private headers = {
        headers: new HttpHeaders({
            Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
        })
    };
    constructor(
        private http: HttpClient
    ) {}

    saveRequest(params) {
        return this.http.post(`${environment.apiUrl}request/add`, params, this.headers);
    }
}