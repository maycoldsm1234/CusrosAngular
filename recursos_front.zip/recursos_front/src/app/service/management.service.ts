import { environment } from './../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class ManagementService {
    private headers = {
        headers: new HttpHeaders({
            Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
        })
    };
    constructor (
        private http: HttpClient
    ) {}

    saveManagement(params: FormData) {
        return this.http.post<any>(`${environment.apiUrl}request/management/add`, params, this.headers);
    }

    getManagements(idRequest) {
        return this.http.get<any>(`${environment.apiUrl}request/management/get?idRequest=${idRequest}`);
    }
}