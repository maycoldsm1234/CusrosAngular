import { Injectable } from "@angular/core";
import Swal from 'sweetalert2';

@Injectable({
    providedIn: 'root'
})
export class AlertService {
    constructor() {}

    confirm(
        title: string,
        text: string,
        type: string,
        confirmButtonText: string = 'Si',
        cancelButtonText: string = 'No'
    ) {
        return new Promise<any>(resolve => {
            Swal.fire({
                title: title,
                text: text,
                confirmButtonText: confirmButtonText,
                cancelButtonText: cancelButtonText,
                showCancelButton: true,
            }).then(
                (result) => {
                    if (result.value) {
                        resolve(true);
                    } else {
                        resolve(false);
                    }
                }
            );
        });
    }
}