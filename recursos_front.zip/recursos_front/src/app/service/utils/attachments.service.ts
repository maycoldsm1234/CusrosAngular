import { environment } from './../../../environments/environment';
import { HttpClient } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class AttachmentsService {
    constructor(
        private http: HttpClient
    ) {}

    downloadAttached(path) {
        const url = `${environment.apiUrl}request/download/attachment?path=${path}`;
        window.open(url, '_blank');
    }
}