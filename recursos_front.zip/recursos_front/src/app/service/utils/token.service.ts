import { environment } from './../../../environments/environment';
import { JwtHelperService } from '@auth0/angular-jwt';
import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Router } from '@angular/router';
import { Observable } from 'rxjs';
import { subscribeOn } from 'rxjs/operators';


@Injectable({
  providedIn: 'root'
})
export class TokenService {
  constructor(
    private http: HttpClient,
    private router: Router
  ) {  }

  structureParams(params) {
    const token = localStorage.getItem('resourceToken');

    return {
      ...params,
      token
    };
  }

  setToken(token) {
    localStorage.setItem('resourceToken', token);

    if (localStorage.getItem('resourceToken') !== null) {
      return true;
    } else {
      return false;
    }
  }

  getDataToken(){
    const tokenUser     = localStorage.getItem('resourceToken');
    const objHelper     = new JwtHelperService();
    let dataToken = null;
    if(tokenUser){
        const objDataToken = objHelper.decodeToken(tokenUser);
        if(objDataToken){
            dataToken = objDataToken;
        }
    }
    return dataToken;
  }

  getDataUserFromToken() {
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
      })
    };
    return this.http.post(`${environment.apiUrl}auth/me`, {}, httpOptions);
  }
}
