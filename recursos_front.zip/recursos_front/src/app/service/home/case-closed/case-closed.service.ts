import { HttpClient } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { CaseClosed } from 'src/app/model/case-closed.model';
import { environment } from 'src/environments/environment';
import { TokenService } from '../../utils/token.service';

@Injectable()
export class CaseClosedService {
    constructor(private http: HttpClient, private token: TokenService) {}

    getCasesClosedByProvider(params) {
      params = this.token.structureParams(params);
      return this.http.post<CaseClosed>(`${ environment.apiUrl }cases/provider/listclose`, params);
    }

    getFields(params) {
      params = this.token.structureParams(params);
      return this.http.post<CaseClosed>(`${ environment.apiUrl }generic/listDataFieldsCloseCase`, params);
    }

    saveClosed(params){
      return this.http.post<CaseClosed>(`${ environment.apiUrl }cases/provider/saveclose`, params);
    }

    getClosed(params){
      params = this.token.structureParams(params);
      return this.http.post<CaseClosed>(`${ environment.apiUrl }cases/provider/getclose`, params);
    }

    getClosedObservations(params){
      params = this.token.structureParams(params);
      return this.http.post<CaseClosed>(`${ environment.apiUrl }cases/provider/getcloseobservations`, params);
    }

    saveClosedObservations(params){
      params = this.token.structureParams(params);
      return this.http.post<CaseClosed>(`${ environment.apiUrl }cases/provider/savecloseobservations`, params);
    }

    getCountCloseCases() {
      let params = this.token.structureParams([]);
    	return this.http.post<any>(`${environment.apiUrl}cases/provider/countCloseCases`, params);
    }

    getRequests(params) {
      return this.http.post<any>('', params);
    }
}
