import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class UsersService {
    private httpOptions = {};

    constructor(
        private http: HttpClient
    ) {
        this.httpOptions = {
            headers: new HttpHeaders({
                Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
            })
        };
    }

    getUsers(params) {
        return this.http.post<any>(`${environment.apiUrl}user/getAll`, params, this.httpOptions);
    }
    
    getUsersByCategory(params) {
        return this.http.post<any>(`${environment.apiUrl}user/getUsersByCategory`, params, this.httpOptions);
    }

    update(user) {
        return this.http.post<any>(`${environment.apiUrl}user/update`, user);
    }

    add(user) {
        return this.http.post<any>(`${environment.apiUrl}user/add`, user);
    }

    delete(idUser) {
        return this.http.post<any>(`${environment.apiUrl}user/delete`, { idUser });
    }

    upload(users) {
        return this.http.post<any>(`${environment.apiUrl}user/import`, users);
    }

    getRoles() {
        return this.http.get(`${environment.apiUrl}rol/get`);
    }

    getRolesByUser(params) {
        return this.http.post(`${environment.apiUrl}rol/get/byUser`, params);
    }

    assignRole(params) {
        return this.http.post(`${environment.apiUrl}rol/assign`, params);
    }

    setAssigned(params) {
        return this.http.post(`${environment.apiUrl}request/assigned/update`, params, this.httpOptions);
    }

    getAllUsers() {
        return this.http.get<any>(`${environment.apiUrl}user/manager/getAll`);
    }
}