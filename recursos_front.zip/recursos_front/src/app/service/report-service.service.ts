import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { ReportResult } from '../model/ReportResult';
import { environment } from 'src/environments/environment';
import { TokenService } from './utils/token.service';

@Injectable({
  providedIn: 'root'
})
export class ReportServiceService {

  httpOptions = {
    headers: new HttpHeaders({
      'Content-Type': 'application/json',
      'Access-Control-Allow-Credentials': 'true',
      'Access-Control-Allow-Origin': '*'
    })
  };
  idUser: any;

  constructor(private http: HttpClient, private token: TokenService) {

  }

  generateReport(data) {
    const params = {
      data
    };
    const httpOptions = {
      headers: new HttpHeaders({
        Authorization: 'Bearer ' + localStorage.getItem('resourceToken'),
        responseType: 'blob'
      })
    };

    return this.http.post<any>(`${environment.apiUrl}generate/report`, params, { observe: 'response', responseType: 'blob' as 'json' });
  }
}
