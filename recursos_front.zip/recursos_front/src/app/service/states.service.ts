import { TokenService } from './utils/token.service';
import { environment } from '../../environments/environment';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { Injectable } from "@angular/core";

@Injectable({
    providedIn: 'root'
})
export class StatesService {
    private httpOptions = {
        headers: new HttpHeaders({
            Authorization: 'Bearer ' + localStorage.getItem('resourceToken')
        })
    };
    constructor(
        private http: HttpClient
    ) {}

    getStates() {
        return this.http.get<any>(`${environment.apiUrl}state/get`);
    }

    getAllStates() {
        return this.http.get<any>(`${environment.apiUrl}state/get/all`);
    }

    update(params) {

        return this.http.post<any>(`${environment.apiUrl}state/update`, params, this.httpOptions);
    }

    add(params) {
        return this.http.post<any>(`${environment.apiUrl}state/add`, params, this.httpOptions);
    }

    delete(idState) {

        return this.http.post<any>(`${environment.apiUrl}state/delete`, {idState}, this.httpOptions);
    }
}