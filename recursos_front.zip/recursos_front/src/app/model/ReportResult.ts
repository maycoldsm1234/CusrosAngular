export interface ReportResult {
    token:String,
    from_date: Date,
    to_date: Date
}