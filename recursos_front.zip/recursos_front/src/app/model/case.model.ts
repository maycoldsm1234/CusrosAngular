export class Case {
    result: any
}