export interface SaveRequest {
    categorie_id: number;
    attachments: string;
    description: string;
}