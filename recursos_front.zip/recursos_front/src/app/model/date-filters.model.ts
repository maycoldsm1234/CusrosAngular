export interface DateFilter {
    start_date: Date,
    end_date: Date
}