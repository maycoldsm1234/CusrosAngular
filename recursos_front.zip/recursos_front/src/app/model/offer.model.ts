export class Offer {
    result: any
}