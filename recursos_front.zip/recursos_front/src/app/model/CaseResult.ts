export interface CaseResult {
    caseNumber: string,
    department: number,
    service: number,
    licensePlate: string,
    date: Date,
    token: String
}