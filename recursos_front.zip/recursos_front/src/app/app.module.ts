import { BrowserAnimationsModule } from "@angular/platform-browser/animations";
import { NgModule } from "@angular/core";
import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { ToastrModule } from 'ngx-toastr';
import { AppComponent } from "./app.component";
import { AdminLayoutComponent } from "./layouts/admin-layout/admin-layout.component";
import { LoginLayoutComponent } from "./layouts/login-layout/login-layout.component";
import { NgbModule } from "@ng-bootstrap/ng-bootstrap";
import { AppRoutingModule } from "./app-routing.module";
import { ComponentsModule } from "./components/components.module";
import { CaseClosedService } from './service/home/case-closed/case-closed.service';
import { ReportServiceService } from './service/report-service.service';
import { DataTablesModule } from 'angular-datatables';
import { UsersComponent } from './pages/users/users.component';

@NgModule({
  imports: [
    BrowserAnimationsModule,
    FormsModule,
    NgbModule,
    AppRoutingModule,
    ComponentsModule,
    HttpClientModule,
    NgbModule,
    RouterModule,
    AppRoutingModule,
    ToastrModule.forRoot({
      timeOut: 6000,
      positionClass: 'toast-top-right'
    }),
    DataTablesModule
  ],
  declarations: [
    AppComponent,
    AdminLayoutComponent,
    LoginLayoutComponent,
    // UsersComponent
  ],
  providers: [CaseClosedService, ReportServiceService],
  bootstrap: [AppComponent]
})
export class AppModule { }
