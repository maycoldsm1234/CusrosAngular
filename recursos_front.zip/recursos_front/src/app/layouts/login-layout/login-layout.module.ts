import { ComponentsModule } from './../../components/components.module';
import { NgModule } from "@angular/core";
import { HttpClientModule } from "@angular/common/http";
import { RouterModule } from "@angular/router";
import { CommonModule } from "@angular/common";
import { FormsModule, ReactiveFormsModule } from "@angular/forms";

import { LoginLayoutRoutes } from "./login-layout.routing";
import { LoginComponent } from "../../pages/login/login.component";

import { NgbModule } from "@ng-bootstrap/ng-bootstrap";

@NgModule({
  imports: [
    CommonModule,
    RouterModule.forChild(LoginLayoutRoutes),
    FormsModule,
    HttpClientModule,
    NgbModule,
    ReactiveFormsModule,
    ComponentsModule
  ],
  declarations: [
    LoginComponent,
  ]
})
export class LoginLayoutModule {}
