import { Component, OnInit } from "@angular/core";
import { Router } from '@angular/router';

@Component({
  selector: "app-login-layout",
  templateUrl: "./login-layout.component.html",
  styleUrls: ["./login-layout.component.scss"]
})
export class LoginLayoutComponent implements OnInit {
  public sidebarColor: string = "red";

  constructor(
    private _router: Router
  ) {}

  ngOnInit() {
    const token = localStorage.getItem('resourceToken');

    if (token !== undefined && token !== null) {
      this._router.navigate([
        '/home'
      ]);
    }
  }
}
