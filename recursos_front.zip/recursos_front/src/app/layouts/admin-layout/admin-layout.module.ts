import { RolesComponent } from './../../pages/roles/roles.component';
import { StatesComponent } from './../../pages/states/states.component';
import { AlertService } from './../../service/utils/alert.service';
import { AttachmentsService } from './../../service/utils/attachments.service';
import { ManagementService } from './../../service/management.service';
import { StatesService } from './../../service/states.service';
import { PanelsService } from './../../service/panels.service';
import { RequestsService } from './../../service/requests.service';
import { AreasService } from './../../service/areas.service';
import { SubcategoriesService } from './../../service/subcategories.service';
import { NgModule } from '@angular/core';
import { HttpClientModule } from '@angular/common/http';
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';

import { AdminLayoutRoutes } from './admin-layout.routing';
import { FilterComponent } from '../../pages/home/filter/filter.component';
import { MatTableModule } from '@angular/material/table';
import { MatSelectModule } from '@angular/material/select';
import { MatIconModule } from '@angular/material/icon';
import { MatPaginatorModule } from '@angular/material/paginator';
import { MatDialogModule, MatCheckboxModule, MatCardModule, MatExpansionModule } from '@angular/material';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { ReportPageComponent } from '../../pages/report/report-page/report-page.component';
import { ComponentsModule } from '../../components/components.module';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { NgxMatSelectSearchModule } from 'ngx-mat-select-search';

// Modals
import { ListManagementComponent } from './../../pages/panels/modals/managements/list/list-management.component';
import { CreateManagementComponent } from 'src/app/pages/panels/modals/managements/create/create-management.component';
import { CreateEditCategoryComponent } from 'src/app/pages/categories/modals/create-edit/create-edit-category.component';
import { CreateEditAreaComponent } from 'src/app/pages/areas/modals/create-edit-area/create-edit-area.component';
import { CreateEditSubcategoryComponent } from 'src/app/pages/subcategories/modals/create-edit-subcategory/create-edit-subcategory.component';

import { TimesComponent } from 'src/app/pages/times/times.component';
import { RequestsComponent } from 'src/app/pages/requests/requests.component';
import { PanelsComponent } from 'src/app/pages/panels/panels.component';
import { UploadsComponent } from 'src/app/pages/uploads/uploads.component';
import { UsersComponent } from 'src/app/pages/users/users.component';
import { CategoriesComponent } from 'src/app/pages/categories/categories.component';
import { CreateEditUsersComponent } from 'src/app/pages/users/modals/create-edit/create-edit-users.component';
import { CreateEditStatesComponent } from 'src/app/pages/states/modals/create-edit/create-edit-states.component';
import { EditRoleUserComponent } from 'src/app/pages/roles/modals/edit/edit-role-user.component';
import { EditCategoryRequestComponent } from 'src/app/pages/panels/modals/categories/edit-category-request.component';
import { CreateEditComponent } from 'src/app/pages/times/modals/create-edit/create-edit.component';
import { EditAssignedRequestComponent } from 'src/app/pages/panels/modals/assigned/edit-assigned-request.component';
import { AreasComponent } from 'src/app/pages/areas/areas.component';
import { SubcategoriesComponent } from 'src/app/pages/subcategories/subcategories.component';
import { InstructiveComponent } from 'src/app/pages/instructive/instructive.component';
import { InstructiveService } from 'src/app/service/instructive.service';

@NgModule({
  imports: [
    CommonModule,
    FormsModule,
    HttpClientModule,
    NgbModule,
    MatTableModule,
    MatIconModule,
    MatPaginatorModule,
    MatSelectModule,
    ReactiveFormsModule.withConfig({warnOnNgModelWithFormControl: 'never'}),
    MatDialogModule,
    MatButtonModule,
    MatFormFieldModule,
    MatCheckboxModule,
    RouterModule.forChild(AdminLayoutRoutes),
    ComponentsModule,
    NgxMatSelectSearchModule,
    MatCardModule,
    MatExpansionModule
  ],
  declarations: [
    ReportPageComponent,
    FilterComponent,
    RequestsComponent,
    TimesComponent,
    PanelsComponent,
    UploadsComponent,
    UsersComponent,
    CategoriesComponent,
    StatesComponent,
    ListManagementComponent,
    CreateManagementComponent,
    CreateEditUsersComponent,
    CreateEditStatesComponent,
    CreateEditCategoryComponent,
    RolesComponent,
    EditRoleUserComponent,
    EditCategoryRequestComponent,
    EditAssignedRequestComponent,
    AreasComponent,
    CreateEditAreaComponent,
    SubcategoriesComponent,
    CreateEditSubcategoryComponent,
    CreateEditComponent,
    InstructiveComponent
  ],
  entryComponents: [
    ListManagementComponent,
    CreateManagementComponent,
    CreateEditUsersComponent,
    CreateEditStatesComponent,
    CreateEditCategoryComponent,
    EditRoleUserComponent,
    EditCategoryRequestComponent,
    EditAssignedRequestComponent,
    CreateEditAreaComponent,
    CreateEditSubcategoryComponent,
    CreateEditComponent
  ],
  providers: [
    RequestsService,
    PanelsService,
    StatesService,
    ManagementService,
    AttachmentsService,
    AlertService,
    AreasService,
    SubcategoriesService,
    InstructiveService
  ]

})
export class AdminLayoutModule {}
