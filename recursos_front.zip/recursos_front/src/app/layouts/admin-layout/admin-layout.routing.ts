import { RolesComponent } from './../../pages/roles/roles.component';
import { StatesComponent } from './../../pages/states/states.component';
import { RequestsComponent } from './../../pages/requests/requests.component';
import { UsersComponent } from './../../pages/users/users.component';
import { PanelsComponent } from './../../pages/panels/panels.component';
import { UploadsComponent } from './../../pages/uploads/uploads.component';
import { CategoriesComponent } from './../../pages/categories/categories.component';
import { TimesComponent } from './../../pages/times/times.component';
import { Routes } from "@angular/router";

import { ReportPageComponent } from "../../pages/report/report-page/report-page.component";
import { AreasComponent } from './../../pages/areas/areas.component';
import { SubcategoriesComponent } from './../../pages/subcategories/subcategories.component';
import { InstructiveComponent } from 'src/app/pages/instructive/instructive.component';


export const AdminLayoutRoutes: Routes = [
  { path: "home", component: PanelsComponent },
  { path: "requests", component: RequestsComponent},
  { path: "users", component: UsersComponent},
  { path: "reportPage", component: ReportPageComponent },
  { path: "uploads", component: UploadsComponent },
  { path: 'states', component: StatesComponent },
  { path: 'categories', component: CategoriesComponent },
  { path: 'roles', component: RolesComponent },
  { path: 'areas', component: AreasComponent },
  { path: 'subcategories', component: SubcategoriesComponent},
  { path: 'times', component: TimesComponent },
  { path: 'instructive', component: InstructiveComponent}
];
