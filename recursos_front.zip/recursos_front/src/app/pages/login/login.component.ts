import { Router } from '@angular/router';
import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators, FormBuilder } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { LoginService } from 'src/app/service/login.service';
import { TokenService } from 'src/app/service/utils/token.service';

@Component({
  selector: 'app-login',
  templateUrl: 'login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent implements OnInit {

  public loginForm: FormGroup;
  public preloader: boolean;
  public data = new FormData();

  constructor(
    private objToastrService: ToastrService,
    private loginService: LoginService,
    private formBuilder: FormBuilder,
    private tokenService: TokenService,
    private _router: Router
  ) {}

  ngOnInit() {
    this.loadForm();
  }

  /**
   * @date 21-05-2020
   * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
   * @description Funcion para construir el formulario del logIn
   */
  loadForm() {
    this.loginForm = this.formBuilder.group({
      user: new FormControl('', Validators.required),
      password: new FormControl('', Validators.required)
    });
  }

  /**
   * @date 21-05-2020
   * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
   * @description Función que consume la API del logIn 
   * y guarda el token en el localStorage
   */
  logIn() {
    this.preloader = true;

    this.data.append('user', this.loginForm.controls['user'].value);
    this.data.append('password', this.loginForm.controls['password'].value);

    this.loginService.login(this.data).subscribe(resp => {
      if (resp.status) {
        if (resp.data.token !== undefined) {
          this.tokenService.setToken(resp.data.token);
          this._router.navigate([
            '/home'
          ]);
        } else {
          this.objToastrService.warning(resp.message, 'ALERTA:');
          this.preloader = false;
        }
      } else {
        this.preloader = false;
        this.objToastrService.warning(resp.message, 'ALERTA:');
      }
    }, (error) => {
      this.preloader = false;
      this.objToastrService.error('ERROR:');
    });
  }
}
