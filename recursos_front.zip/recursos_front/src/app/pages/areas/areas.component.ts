import { Component, OnInit, ViewChild } from "@angular/core";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatDialog,
} from "@angular/material";
import { AlertService } from "src/app/service/utils/alert.service";
import { ToastrService } from "ngx-toastr";
import { AreasService } from "src/app/service/areas.service";
import { CreateEditAreaComponent } from "./modals/create-edit-area/create-edit-area.component";

@Component({
  selector: "app-areas",
  templateUrl: "./areas.component.html",
})
export class AreasComponent implements OnInit {
  public dataSource = new MatTableDataSource<any>([]);
  public searchResult: boolean = false;
  public emptyData: boolean = false;
  public preloader: boolean;

  @ViewChild(MatPaginator, { static: true }) public paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) public sort: MatSort;

  public displayedColumns: string[] = [
    "actions",
    "name",
    "manager",
    "created_by",
    "created_at",
    "updated_by",
    "updated_at",
    "status",
  ];

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private objToastrService: ToastrService,
    private AreasService: AreasService,
  ) {}

  ngOnInit() {
    this.getAreas();
  }

  getAreas() {
    this.preloader = true;
    this.AreasService.getAll().subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.setDataAreas(response.data);
        } else {
          this.objToastrService.error("ERROR");
        }
        this.preloader = false;
      },
      () => {
        this.objToastrService.error("ERROR");
        this.preloader = false;
      }
    );
  }

  setDataAreas(data) {
    this.dataSource = new MatTableDataSource<any>(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      if (data.name) {
        return data.name.toLowerCase().includes(filter);
      }
    };
    if (this.dataSource.data.length === 0 && this.searchResult) {
      this.emptyData = true;
    }
    this.preloader = false;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  save(area = { name: "", manager: null, id: null, status: null}) {
    let title = "Crear";
    if (area.id) {
      title = "Editar";
    }
    const dialogRef = this.dialog.open(CreateEditAreaComponent, {
      data: {
        area,
        title: title,
      },
      width: "300px",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === "ok") {
        this.ngOnInit();
      }
    });
  }

  deleteArea(id) {
    this.alertService
      .confirm(
        "<h1>Eliminar gerencia</h1>",
        "¿Esta seguro que desea eliminar la gerencia?",
        "question"
      )
      .then((res) => {
        if (res) {
          const params = { idIntArea: id };
          this.AreasService.deleteArea(params).subscribe((response: any) => {
            if (response.status === 200) {
              if(response.data === 'RESTRICT'){
                this.objToastrService.warning("No se puede eliminar la gerencia, hay registros que dependen de ella", "ALERTA:");
              }else{
                this.objToastrService.success(
                  "Registro eliminado correctamente.",
                  "EXITO:"
                );
              }
              this.ngOnInit();
            } else {
              this.objToastrService.error(response.msm, "ERROR:");
            }
          });
        }
      });
  }
}
