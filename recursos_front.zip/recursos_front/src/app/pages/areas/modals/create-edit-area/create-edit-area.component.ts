import { Component, OnInit, Inject } from "@angular/core";
import {
  FormBuilder,
  FormGroup,
  Validators,
  FormControl,
} from "@angular/forms";
import { AreasService } from "src/app/service/areas.service";
import { UsersService } from "src/app/service/users.service";
import { ToastrService } from "ngx-toastr";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { Subject, ReplaySubject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';

@Component({
  selector: "app-create-edit-area",
  templateUrl: "./create-edit-area.component.html",
  styleUrls: ["./create-edit-area.component.scss"],
})
export class CreateEditAreaComponent implements OnInit {
  public areaForm: FormGroup;
  public preloader: boolean;
  public title: string;
  public formData = new FormData();
  public managerSearch = new FormControl();
  protected managerDestroy = new Subject<void>();
  public filteredmanager = new ReplaySubject<any[]>(1);

  public status = [
    { id: 0, label: "Activa" },
    { id: 1, label: "Inactiva" },
  ];

  public users = [];

  constructor(
    private areaService: AreasService,
    private usersService: UsersService,
    private objToastrService: ToastrService,
    private formbuilder: FormBuilder,
    private dialogRef: MatDialogRef<CreateEditAreaComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.title = this.data["title"];
    this.setDataUsers();
    this.searchChanged();  
    this.buildForm();
  }

  setDataUsers() {
    this.usersService.getAllUsers().subscribe(
      (response: any) => {
        if (response.status === 200) {
          this.users = response.data;
          this.filteredmanager.next(this.users.slice());
        } else {
          this.objToastrService.error("Error listando los usuarios.", "ERROR:");
        }
        this.preloader = false;
      },
      () => {
        this.objToastrService.error("Error listando los usuarios.", "ERROR:");
        this.preloader = false;
      }
    );
  }

  searchChanged() {
    this.managerSearch.valueChanges
      .pipe(takeUntil(this.managerDestroy))
      .subscribe(() => {
        this.filterManager();
      });
  }

  filterManager() {
    if (!this.users) {
      this.filteredmanager.next(this.users.slice());
      return;
    }

    let search = this.managerSearch.value;

    if (!search) {
      return;
    } else {
      search = search.toLowerCase();
    }

    this.filteredmanager.next(
      this.users.filter(
        (option) => option.name.toLowerCase().indexOf(search) > -1
      )
    );
  }

  buildForm() {
    this.areaForm = this.formbuilder.group({
      idIntArea: [null],
      name: new FormControl(
        this.data["area"].name ? this.data["area"].name : "",
        Validators.required
      ),
      manager: new FormControl(
        this.data["area"].manager ? this.data["area"].manager : "",
        Validators.required
      ),
      status: new FormControl(
        this.data["area"].deleted != undefined ? this.data["area"].deleted : ""
      ),
    });
  }

  

  save() {
    if (this.areaForm.invalid) {
      this.objToastrService.warning("Debe llenar todos los campos.", "ALERTA:");
    } else {
      this.preloader = true;
      if (!this.data["area"].id) {
        this.areaForm.get("status").setValue(0);
      }else{
        this.areaForm.get("idIntArea").setValue(this.data["area"].id);
      }

      let area = this.areaForm.value;
      this.areaService.saveArea(area).subscribe(
        (response: any) => {
          if (response.status === 200) {
            if(response.data === 'EXIST_AREA'){
              this.objToastrService.warning("Ya existe una gerencia con este nombre", "ALERTA:");
            }else{
              this.objToastrService.success(
                "Registros guardados exitosamente.",
                "EXITO:"
              );
              this.dialogRef.close("ok");
            }
          } else {
            this.objToastrService.error(
              "Error guardando los registros.",
              "ERROR:"
            );
          }
          this.preloader = false;
        }
      );
    }
  }
}
