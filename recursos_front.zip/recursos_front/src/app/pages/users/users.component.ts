import { ToastrService } from 'ngx-toastr';
import { AlertService } from './../../service/utils/alert.service';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { UsersService } from './../../service/users.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { CreateEditUsersComponent } from './modals/create-edit/create-edit-users.component';
import { AreasService } from 'src/app/service/areas.service';
import { TokenService } from 'src/app/service/utils/token.service';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;

@Component({
    selector: 'app-users',
    templateUrl: './users.component.html',
    styleUrls: ['./users.component.scss']
})
export class UsersComponent implements OnInit {
    public dataSource = new MatTableDataSource<any>([]);
    public paginatorLength: number;
    public flagPaginator: boolean;
    public searchResult: boolean;
    public emptyData: boolean;
    public preloader: boolean;
    public areas: [];
    public area: number;
    public userData: any;
    public showAreas: boolean = false;
    
    public displayedColumns = [
        'actions',
        'user_name',
        'name',
        'email',
        'boss',
        'area',
        'manager'
    ];
    
    @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
    @ViewChild(MatSort, {static: true}) sort: MatSort;
    
    constructor(
        private userService: UsersService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private objToastrService: ToastrService,
        private areaService: AreasService,
        private tokenService: TokenService
        ) { }
        
    ngOnInit() {
        this.getDataUser();
        
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            if (this.userData.role_id === ROL_ADMIN) {
                this.showAreas = true;
            } else if (this.userData.role_id === ROL_AUDITOR) {
                this.showAreas = true;
            }
            this.getAreas();
        }, (error) => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    getAreas() {
        this.areaService.getAll().subscribe((res: any) => {
            if (res.status === 200) {

                if(this.userData.role_id === ROL_ADMIN){
                    this.areas = res.data.filter(
                        (area) => area.deleted === 0 && area.id === 0 || area.id === this.userData.area_id
                    );
                }else{
                    this.areas = res.data.filter(
                        (area) => area.deleted === 0
                    );
                }
            } else {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    areaByUser() {
        this.getUsers(this.area);
    }
    
    getUsers(area: number) {
        this.preloader = true;
        const params = {
            idArea: area
        };
        this.userService.getUsers(params).subscribe(res => {
            if (res.status === 200) {
                const usersData: any[] = [];
                res.data.forEach(element => {
                    let boss = '';
                    let manager = '';
                    let area = ''
                    
                    if (element.boss !== null) {
                        boss = element.boss;
                    }
                    
                    if (element.manager !== null) {
                        manager = element.manager;
                    }

                    if (element.area !== null) {
                        area = element.area;
                    }
                    
                    usersData.push({
                        user: element,
                        user_name: element.user_name,
                        name: element.name,
                        email: element.email,
                        boss,
                        area,
                        manager,
                    });
                });
                this.setData(usersData);
            } else {
                this.preloader = false;
                this.emptyData = true;
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.preloader = false;
            this.emptyData = true;
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }
        
    setData(data: any[]) {
        this.dataSource = new MatTableDataSource(data);
        this.paginatorLength = data.length;
        this.dataSource.paginator = this.paginator;
        this.dataSource.filterPredicate = function(data, filter: string): boolean {
            if (data.user_name) {
                if(data.boss.name) {
                    return data.user_name.toLowerCase().includes(filter)  || 
                    data.boss.name.toLowerCase().includes(filter);
                } else {
                    return data.user_name.toLowerCase().includes(filter);
                }
            }
        };
        if (this.dataSource.data.length === 0 && this.searchResult) {
            this.emptyData = true;
        }
        
        this.preloader = false;
        this.objToastrService.success('Registros consultados exitosamente.', 'EXITO:');
    }
        
    editUser(user) {
        const dialogRef = this.dialog.open(CreateEditUsersComponent, {
            data: {
                user,
                title: 'Editar'
            },
            width: '700px',
            disableClose: true
        });
        
        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result === 'ok') {
                    this.ngOnInit();
                    this.areaByUser();
                }
        });
    }
            
    addUser() {
        const dialogRef = this.dialog.open(CreateEditUsersComponent, {
            data: {
                title: 'Crear'
            },
            width: '700px',
            disableClose: true
        });
        
        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result === 'ok') {
                    this.ngOnInit();
                    this.areaByUser();
                }
        });
    }
                
    deleteUser(id) {
    this.alertService.confirm(
        '<h1>Eliminar usuario</h1>',
        '¿Esta seguro que desea eliminar el usuario?',
        'question'
        ).then(
            res => {
                if (res) {
                    this.userService.delete(id).subscribe(
                        (resp) => {
                            if (resp.status === 200) {
                                this.objToastrService.success('Registro eliminado correctamente.', 'EXITO:');
                                this.ngOnInit();
                                this.areaByUser();
                            } else {
                                this.objToastrService.error('Error eliminando el registro.', 'ERROR:');
                            }
                    })
                }
        });
    }
            
    /**
    * @date(28-05-2020)
    * @author Kevin Londoño Benitez <kevin.londono@grupokonecta.com>
    * @description Metodo para filtrar la información de la tabla
    * @param filterValue  Texto por le cual se filtrará
    **/
    applyFilter(filterValue: string) {
        filterValue = filterValue.trim();
        filterValue = filterValue.toLowerCase();
        this.dataSource.filter = filterValue;
    }
}
