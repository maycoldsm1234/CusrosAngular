import { takeUntil } from 'rxjs/operators';
import { Subject, ReplaySubject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
import { UsersService } from './../../../../service/users.service';
import { Component, OnInit, Inject } from "@angular/core";
import { DIR_DOCUMENT } from '@angular/cdk/bidi';
import { AreasService } from 'src/app/service/areas.service';

@Component({
    selector: 'app-create-edit-users',
    templateUrl: './create-edit-users.component.html',
    styleUrls: ['./create-edit-users.component.scss']
})
export class CreateEditUsersComponent implements OnInit {
    public usersForm: FormGroup;
    public preloader: boolean;
    public title: string;

    public bossOptions: any[] = [];
    public bossSearch = new FormControl();
    protected bossDestroy = new Subject<void>();
    public filteredBoss: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    public managerOptions = [];
    public managerSearch = new FormControl();
    protected managerDestroy = new Subject<void>();
    public filteredManager: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    public areas: any;
    public managerInfo = "";
    public managerId:number;
    public gerencia: any;
    public formData = new FormData();
    public email = new FormControl('');

    constructor(
        private dialogRef: MatDialogRef<CreateEditUsersComponent>,
        private usersService: UsersService,
        private formBuild: FormBuilder,
        private objToastrService: ToastrService,
        private areaService: AreasService,
        @Inject(MAT_DIALOG_DATA) private data: any
    ) {}

    ngOnInit() {
        this.title = this.data['title'];
        this.buildForm();
        this.getAreas();
        // this.getBossUsers();
        // this.getManagerUsers();
        this.searchChanged();
    }

    searchChanged() {
        this.managerSearch.valueChanges
            .pipe(takeUntil(this.managerDestroy))
            .subscribe(() => {
                this.filterManager();
            }
        );

        this.bossSearch.valueChanges
            .pipe(takeUntil(this.bossDestroy))
            .subscribe(() => {
                this.filterBoss();
            }
        );
    }

    filterBoss() {
        if (!this.bossOptions) {
            return;
        }

        let search = this.bossSearch.value;

        if (!search) {
            this.filteredBoss.next(this.bossOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredBoss.next(
            this.bossOptions.filter(option => option.name
                                        .toLowerCase()
                                        .indexOf(search) > -1)
        );
    }

    filterManager() {
        if (!this.managerOptions) {
            return;
        }

        let search = this.managerSearch.value;

        if (!search) {
            this.filteredManager.next(this.managerOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredManager.next(
            this.managerOptions.filter(option => option.name.toLowerCase().indexOf(search) > -1)
        );
    }

    buildForm() {
        this.usersForm = this.formBuild.group({
            user_name: new FormControl('', Validators.required),
            name: new FormControl('', Validators.required),
            email: new FormControl('', Validators.email),
            boss_user_id: new FormControl(''),
            manager_operation_user_id: new FormControl(''),
            area_id: new FormControl('', Validators.required),
        });

        this.setDataUser();
    }

    isValidMail(val){
        let valid = false;
        if (val === '' || val === null){
            valid = true;
        }else{
            const regex = /^[a-zA-Z0-9_.+-]+@(?:(?:[a-zA-Z0-9-]+\.)?[a-zA-Z]+\.)?(grupokonecta)\.(com$|co$)/gm; 
            const str = val; 
            let m; 
            while ((m = regex.exec(str)) !== null) {
                 // This is necessary to avoid infinite loops with zero-width matches 
                 if (m.index === regex.lastIndex) {
                      regex.lastIndex++; 
                } // The result can be accessed through the `m`-variable. 
                m.forEach((match, groupIndex) => 
                {
                    valid = true; 
                }); 
            }
        }
        return valid;
    }

      

    setDataUser() {
        if (this.data['user'] !== undefined) {
            this.usersForm.controls['user_name'].setValue(this.data['user'].user_name);
            this.usersForm.controls['name'].setValue(this.data['user'].name);
            this.usersForm.controls['email'].setValue(this.data['user'].email);
            this.usersForm.controls['boss_user_id'].setValue(this.data['user'].boss.id);
            this.usersForm.controls['manager_operation_user_id'].setValue(this.data['user'].manager.name);
        }
    }

    save() {
        const valEmail =  this.isValidMail(this.usersForm.value.email);
        
        if(valEmail == false){
            this.objToastrService.warning('El correo ingresado debe ser de dominio @grupokonecta', 'ALERTA:');
        }else if (this.usersForm.invalid) {
            this.objToastrService.warning('Debe llenar todos los campos.', 'ALERTA:');
        } else {
            this.usersForm.controls["manager_operation_user_id"].setValue(this.managerId);
            let user = this.usersForm.value;
            if (this.data['user'] !== undefined) {
                user = {
                    ...user,
                    id: this.data['user'].user.id
                };

                const userData = {
                    user
                };

                this.usersService.update(userData).subscribe(
                    (resp) => {
                        if(resp.data.msm === 'USER_EXIST'){
                            this.objToastrService.warning('El usuario ya se encuentra registrado en la gerencia '+ resp.data.user.area.name, 'ALERTA:');
                        }else if (resp.status === 200) {
                            this.dialogRef.close('ok');
                        } else {
                            this.objToastrService.error('Error guardando el usuario', 'ERROR:');
                        }
                    }, () => {
                        this.objToastrService.error('Error guardando el usuario', 'ERROR:');
                    }
                );
            } else {
                const userData = {
                    user
                };

                this.usersService.add(userData).subscribe(
                    (resp) => {
                        console.log(resp);
                        if(resp.data.msm === 'USER_EXIST'){
                            this.objToastrService.warning('El usuario ya se encuentra registrado en la gerencia '+ resp.data.user.area.name, 'ALERTA:');
                        }else if (resp.status === 200) {
                            this.dialogRef.close('ok');
                        } else {
                            this.objToastrService.error('Error guardando el usuario', 'ERROR:');
                        }
                    }, () => {
                        this.objToastrService.error('Error guardando el usuario', 'ERROR:');
                    }
                );
            }
        }
    }

    getAreas() {
        this.areaService.getAll().subscribe((res: any) => {
            if (res.status === 200) {
                this.areas = res.data.filter(
                    (area) => area.deleted === 0
                );
                if(this.data['user'] !== undefined){
                    this.usersForm.controls['area_id'].setValue(this.data['user'].area.id);
                }
            } else {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    onChangeGerencia(idGerencia){

        if(idGerencia != null){

            this.areas.forEach(element => {
                if(element.id == idGerencia){
                    this.managerInfo = element.manager_user.name;
                    this.managerId = element.manager_user.id;
                }
            });

            this.usersForm.controls["manager_operation_user_id"].setValue(this.managerInfo);

            let params = {
                idArea : idGerencia
              };
        
              this.usersService.getUsers(params).subscribe(
                (resp) => {
                    if (resp.status === 200) {
                        this.bossOptions = resp.data;

                        // if(this.data['user'] !== undefined){
                        //     this.usersForm.controls['boss_user_id'].setValue(this.data['user'].boss.id);
                        // }

                        this.filteredBoss.next(this.bossOptions.slice());
                    } else {
                        this.objToastrService.error('Error obteniendo los usuarios jefes', 'ERROR:');
                    }
                }, () => {
                    this.objToastrService.error('Error obteniendo los usuarios jefes', 'ERROR:');
                }
            );
        }
        
    }
}