import { TokenService } from 'src/app/service/utils/token.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { FormGroup, FormBuilder, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { ReportServiceService } from 'src/app/service/report-service.service';
import { CategoryService } from 'src/app/service/category.service';
import { AreasService } from 'src/app/service/areas.service';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;

@Component({
    selector: 'app-report-page',
    templateUrl: './report-page.component.html',
    styleUrls: ['./report-page.component.scss']
})
export class ReportPageComponent implements OnInit {
    public preloader: boolean;
    public typeReportOptions: any[] = [
        { id: 'my_request', label: 'Solicitudes creadas por mi' },
        { id: 'category_request', label: 'Solicitudes por categoria' },
        { id: 'without_request', label: 'Solicitudes sin gestión' },
        { id: 'all_request', label: 'Todas las solicitudes' }
    ];
    public categoriesOptions: any[] = [];
    public subcategories: any[] = [];
    public parentCategoryCtrl = new FormControl(null);
    public categoryCtrl = new FormControl(null);
    public areaCtrl = new FormControl(null);
    public userData: any;
    public areas: [];
    public area: number;

    FilterGroupDate: FormGroup;
    private dataToken: any;
    public showCategorySelect: boolean = false;
    public showAreaSelect: boolean = false;
    FileSaver = require('file-saver');

    constructor(
        private formBuilder: FormBuilder,
        private objToastrService: ToastrService,
        private objReportService: ReportServiceService,
        private tokenService: TokenService,
        private categoryService: CategoryService,
        private areaService: AreasService,
    ) {
        this.dataToken = this.tokenService.getDataToken();
    }

    ngOnInit() {
        this.getDataUser();
        this.getAreas();
        this.filterFormControl();
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            if (this.userData.role_id === ROL_ADMIN) {
                this.listCategories(this.userData.area_id);
            }
        }, (error) => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    getAreas() {
        this.areaService.getAll().subscribe((res: any) => {
            if (res.status === 200) {
                this.areas = res.data;
            } else {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para consultar las categorias registradas en la base de datos
     */
    listCategories(area: number) {
        this.preloader = true;
        const params = {
            id_Area: area
        };

        this.categoryService.getcategoryByAreaUser(params).subscribe((resp: any) => {
            if (resp.status === 200) {
                this.categoriesOptions =  resp.data.filter(
                    (category) => category.category_id === null && category.active === 1
                  );
                this.preloader = false;
            }
        }, (error) => {
            this.preloader = false;
            this.objToastrService.error('Error consultado la información solicitada', 'ERROR:');
        });
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para construir el formulario.
     */
    filterFormControl() {
        this.FilterGroupDate = this.formBuilder.group({
            first_date: new FormControl('', Validators.required),
            end_date: new FormControl('', Validators.required),
            typeReport: new FormControl('', Validators.required)
        });
    }

    /**
     * @date 02-01-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Metodo ejecutado desde el html para recibir los datos del formulario de busqueda
     */
    generateReport() {
        if (this.FilterGroupDate.invalid) {
            this.objToastrService.warning('Debe llenar todos los campos.', 'ALERTA:');
        } else {
            const first_date = new Date(this.FilterGroupDate.controls['first_date'].value)
                .toISOString()
                .split('T')[0];
            const end_date = new Date(this.FilterGroupDate.controls['end_date'].value)
                .toISOString()
                .split('T')[0];
            const typeReport = this.FilterGroupDate.controls['typeReport'].value;

            if (this.validateDates(first_date, end_date)) {
                this.preloader = true;
                let idCategory = this.categoryCtrl.value;
                if (idCategory === null) {
                    idCategory = this.dataToken.sub;
                }

                const area = this.area;
                const params = {
                    first_date,
                    end_date,
                    typeReport,
                    idCategory,
                    area
                };

                this.objReportService.generateReport(params)
                .subscribe((response: any) => {
                    if (response.status === 200 && response.body.status !== 500) {
                        const blob = new Blob([response.body], { type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' });
                        const url = window.URL.createObjectURL(blob);
                        this.FileSaver.saveAs(blob, 'report.xlsx');
                    } else {
                        this.objToastrService.error('Error generando el reporte.', 'ERROR:');
                    }
                    this.preloader = false;
                }, error => {
                    this.objToastrService.error('Error generando el reporte.', 'ERROR:');
                    this.preloader = false;
                });
            }
        }
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para identificar cuando el select de tipo de reporte cambien
     * para mostrar el select de categorias o no
     */
    changeSelect() {
        this.showAreaSelect = false;
        this.showCategorySelect = false;
        this.areaCtrl.setValue(null);
        this.parentCategoryCtrl.setValue(null);
        this.categoryCtrl.setValue(null);
        const report = this.FilterGroupDate.controls['typeReport'].value;

        if (report == 'without_request' || report == 'all_request') {
            if (this.userData.role_id === ROL_AUDITOR) {
                this.showAreaSelect = true;
            } else {
                this.area = this.userData.area_id;
            }
        } else if (report == 'category_request') {
            this.showCategorySelect = true;
            if (this.userData.role_id === ROL_AUDITOR) {
                this.showAreaSelect = true;
            }
        }
    }

    /**
     * @date 02-01-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Metodo encargado de validar las fechas
     * @return {boolean} Returna true si las validaciones son correctas o false si no son permitidas
     */
    validateDates(startDate, endDate) {
        if (new Date(startDate) > new Date(endDate)) {
            this.objToastrService.warning('La fecha de inicio no puede ser mayor a la fecha de fin', 'ALERTA:');
            return false;
        }

        if (new Date(endDate) > new Date()) {
            this.objToastrService.warning('La fecha de fin no puede ser mayor a la fecha actual', 'ALERTA:');
            return false;
        }

        if (new Date(startDate) > new Date()) {
            this.objToastrService.warning('La fecha de inicio no puede ser mayor a la fecha actual', 'ALERTA:');
            return false;
        }

        return true;
    }

    getSubcategories(event) {
        this.categoryCtrl.setValue(null);
        const params = {
            idIntCategory: event
        };

        this.categoryService.getSubcategoryByCategory(params).subscribe((resp: any) => {
            if (resp.status === 200) {
                this.subcategories = resp.data.filter(
                    (subcategory) => subcategory.active === 1
                  );
            }
        }, (error) => {
            this.preloader = false;
            this.objToastrService.error('Error consultado la información solicitada', 'ERROR:');
        });
    }

    categoryByArea(event) {
        this.parentCategoryCtrl.setValue(null);
        this.categoryCtrl.setValue(null);
        this.area = event;
        this.listCategories(event);
    }
}
