import { RequestsService } from "./../../service/requests.service";
import { ToastrService } from "ngx-toastr";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
} from "@angular/forms";
import { Component, OnInit } from "@angular/core";
import { CategoryService } from "./../../service/category.service";
import { TokenService } from "src/app/service/utils/token.service";
import { SubcategoriesService } from 'src/app/service/subcategories.service';

@Component({
  selector: "app-requests",
  templateUrl: "./requests.component.html",
})
export class RequestsComponent implements OnInit {
  public categoryOptions: any[];
  public subcategoryOptions: any[];
  public allcategories: any[];

  public requestsForm: FormGroup;
  private formData = new FormData();
  public preloader: Boolean = false;
  private fileType = ["pdf", "jpg", "png", "jpeg"];

  private userData: any;

  constructor(
    private formBuilder: FormBuilder,
    private objToastrService: ToastrService,
    private requestsService: RequestsService,
    private categoryService: CategoryService,
    private tokenService: TokenService,
    private subcategoriesService: SubcategoriesService,
  ) {}

  ngOnInit() {
    this.getDataUser();
    this.buildForm();
  }

  /**
   * @date 21-05-2020
   * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
   * @description Funcion para construir el formulario
   */
  buildForm() {
    this.requestsForm = this.formBuilder.group({
      category: new FormControl("", Validators.required),
      subcategory: new FormControl("", Validators.required),
      attachments: new FormControl(""),
      description: new FormControl("", Validators.required),
    });
  }

  /**
   * @date 21-05-2020
   * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
   * @description Funcion para validar los datos del formulario y consumir la API de crear solicitud
   */
  onSave() {
    if (this.requestsForm.invalid) {
      this.objToastrService.warning("Debe llenar todos los campos.");
    } else {
      this.preloader = true;
      const params = this.prepareSave();
      this.requestsService.saveRequest(params).subscribe(
        (response: any) => {
          if (response.status !== 200) {
            this.objToastrService.error(
              "Error creando la solicitud.",
              "ERROR:"
            );
          } else {
            this.objToastrService.success(
              "Registros guardados correctamente.",
              "EXITO:"
            );
            this.resetFormData();
            this.requestsForm.reset();
            this.ngOnInit();
          }
          this.preloader = false;
        },
        (error) => {
          this.objToastrService.error("Error creando la solicitud.");
          this.preloader = false;
        }
      );
    }
  }

  resetFormData(){
    this.formData.delete('category');
    this.formData.delete('attachments');
    this.formData.delete('description');
  }

  /**
   * @date 21-05-2020
   * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
   * @desciption Funcion para capturar los datos del formulario y agregarlos al formData
   */
  prepareSave() {
    this.formData.append("category", this.requestsForm.get("subcategory").value);
    this.formData.append(
      "attachments",
      this.requestsForm.get("attachments").value
    );
    this.formData.append(
      "description",
      this.requestsForm.get("description").value
    );
    return this.formData;
  }

  listCategory() {
    if (this.userData.area_id != null) {
      const params = { id_Area: this.userData.area_id };
      this.categoryService.getcategoryByAreaUser(params).subscribe(
        (response: any) => {
          if (response.status === 200) {
            this.allcategories = response.data;
            const category = response.data.filter(
              (category) => category.category_id === null && category.active === 1
            );
            this.categoryOptions = category;
          }else{
            this.objToastrService.error("No se encontraron categorías para la sede del usuario en sesión.");
          }
        },
        (error) => {
          this.objToastrService.error("Error al consultar las categorías.");
        }
      );
    }
  }

  // Función para el manejo de archivos
  handleFileInput(files: FileList) {
    this.requestsForm.get("attachments").setErrors(null);
    if (files.length > 0) {
      let numFile = 1;
      // Bandera para detener el ciclo en la primera validación erronea
      let flagFileType = true;
      Array.from(files).forEach((file) => {
        if (flagFileType) {
          const extFile = file.name
            .substr(file.name.lastIndexOf(".") + 1)
            .toLowerCase();
          if (this.fileType.find((type) => type === extFile)) {
            this.formData.append("attachments", file, file.name);
          } else {
            this.objToastrService.error("Tipo de archivo no valido", "ERROR:");
            flagFileType = false;
            this.requestsForm.get("attachments").setValue(null);
          }
        }
        if (file.size / 1024 > 4096) {
          this.objToastrService.error(
            "Capacidad de carga superada (Máximo 4mb)",
            "ERROR:"
          );
          this.requestsForm.get("attachments").setValue(null);
        }
      });
    }
  }

  getExtentionFile(str) {
    return str.substr(str.lastIndexOf(".") + 1);
  }

  getDataUser() {
    this.tokenService.getDataUserFromToken().subscribe(
      (res: any) => {
        this.userData = res;
        this.listCategory();
      },
      (error) => {
        this.objToastrService.error("Error consultando los datos.", "ERROR:");
        localStorage.removeItem('resourceToken');
        location.reload();
      }
    );
  }

  onChangeCategory(value: any) {
    const params = {
      idIntCategory: value
    };

    this.subcategoriesService.getsubcategoryBycategory(params).subscribe((response: any) => {
      if (response.status === 200) {
        this.subcategoryOptions = response.data;
      } else {
        this.objToastrService.error("Error consultando los datos.", "ERROR:");
      }
    }, (error) => {
      this.objToastrService.error("Error consultando los datos.", "ERROR:");
    });
  }
}
