import { BreakpointObserver } from '@angular/cdk/layout';
import { UsersService } from './../../service/users.service';
import { AreasService } from './../../service/areas.service';
import { TokenService } from './../../service/utils/token.service';
import { ToastrService } from 'ngx-toastr';
import { AlertService } from './../../service/utils/alert.service';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';
import { Component, OnInit, ViewChild } from '@angular/core';
import { EditRoleUserComponent } from './modals/edit/edit-role-user.component';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;

@Component({
    selector: 'app-roles',
    templateUrl: './roles.component.html',
    styleUrls: ['./roles.component.scss']
})
export class RolesComponent implements OnInit {
    public dataSource = new MatTableDataSource<any>([]);
    public paginatorLength: number;
    public flagPaginator: boolean;
    public searchResult: boolean;
    public emptyData: boolean;
    public preloader: boolean;
    public areas: [];
    public area: number;
    public userData: any;
    public showAreas: boolean = false;

    public displayedColumns = [
        'actions',
        'user_name',
        'user',
        'role',
        'area'
    ];

    @ViewChild(MatPaginator, { static: true }) paginator: MatPaginator;
    @ViewChild(MatSort, { static: true }) sort: MatSort;

    constructor(
        private userService: UsersService,
        private dialog: MatDialog,
        private alertService: AlertService,
        private objToastrService: ToastrService,
        private breakPointObserver: BreakpointObserver,
        private areaService: AreasService,
        private tokenService: TokenService
    ) {
        this.breakPointObserver.observe(['(max-width: 600px)']).subscribe(result => {
            this.displayedColumns = ['actions', 'user_name', 'user', 'role', 'area'];
        });
    }

    ngOnInit() {
        this.getDataUser();
        this.getAreas();
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            if (this.userData.role_id === ROL_ADMIN) {
                this.getUsers(this.userData.area_id);
            } else if (this.userData.role_id === ROL_AUDITOR) {
                this.showAreas = true;
            }
        }, (error) => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    getAreas() {
        this.areaService.getAll().subscribe((res: any) => {
            if (res.status === 200) {
                this.areas = res.data.filter(
                    (area) => area.deleted === 0
                );
            } else {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    areaByUser() {
        if (this.userData.role_id === ROL_AUDITOR) {
            this.getUsers(this.area);
        }
    }

    getUsers(area: number) {
        this.preloader = true;

        const params = {
            idArea: area
        };

        this.userService.getUsers(params).subscribe(res => {
            if (res.status === 200) {
                const usersData: any[] = [];
                res.data.forEach(element => {
                    let role = {};
                    if (element.rol !== null) {
                        role = element.rol;
                    }
                    usersData.push({
                        user: element,
                        role
                    });
                });
                this.setData(usersData);
            } else {
                this.preloader = false;
                this.emptyData = true;
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.preloader = false;
            this.emptyData = true;
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    setData(data: any[]) {
        this.dataSource = new MatTableDataSource<any>(data);
        this.paginatorLength = data.length;
        this.dataSource.paginator = this.paginator;
        this.dataSource.filterPredicate = function(data, filter: string): boolean {
            if (data.user.name) {
                if(data.role.description){
                    return data.user.name.toLowerCase().includes(filter)  || 
                    data.role.description.toLowerCase().includes(filter);
                } else {
                    return data.user.name.toLowerCase().includes(filter);
                }
            }
        };
        if (this.dataSource.data.length === 0 && this.searchResult) {
            this.emptyData = true;
        }

        this.preloader = false;
        this.objToastrService.success('Registros consultados exitosamente.', 'EXITO:');
    }

    assignRol(userId, role) {
        const dialogRef = this.dialog.open(EditRoleUserComponent, {
            data: {
                user: userId,
                role
            },
            disableClose: true,
            width: '300px'
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result === 'ok') {
                    this.ngOnInit();
                }
            }
        );
    }

    /**
     * @date(28-05-2020)
     * @author Kevin Londoño Benitez <kevin.londono@grupokonecta.com>
     * @description Metodo para filtrar la información de la tabla
     * @param filterValue  Texto por le cual se filtrará
    **/
    applyFilter(filterValue: string) {
        filterValue = filterValue.trim();
        filterValue = filterValue.toLowerCase();
        this.dataSource.filter = filterValue;
    }
}
