import { UsersService } from './../../../../service/users.service';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormControl, Validators } from '@angular/forms';
import { Component, OnInit, Inject } from "@angular/core";
import { Subject, ReplaySubject } from 'rxjs';
import { takeUntil } from 'rxjs/operators';
import { TokenService } from './../../../../service/utils/token.service';

@Component({
    selector: 'app-edit-role-user',
    templateUrl: './edit-role-user.component.html',
    styleUrls: ['./edit-role-user.component.scss']
})
export class EditRoleUserComponent implements OnInit {
    public roleOptions: any[];
    public preloader: boolean;
    public title: string;
    public userData: any;

    public roleCtrl = new FormControl('', Validators.required);
    public roleSearch = new FormControl('');
    protected roleDestroy = new Subject<void>();
    public filteredRole: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

    constructor(
        private dialogRef: MatDialogRef<EditRoleUserComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private objToastrService: ToastrService,
        private usersService: UsersService,
        private tokenService: TokenService
    ) {}

    ngOnInit() {
        this.getDataUser();
        // this.searchsChanged();
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            this.getRoles();
        }, (error) => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    searchsChanged() {
        this.roleSearch.valueChanges
            .pipe(takeUntil(this.roleDestroy))
            .subscribe(() => {
                this.filterRole();
            });
    }

    filterRole() {
        if (!this.roleOptions) {
            return;
        }

        let search = this.roleSearch.value;

        if(!search) {
            this.filteredRole.next(this.roleOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredRole.next(
            this.roleOptions.filter(option => option.description
                                                .toLowerCase()
                                                .indexOf(search) > -1)
        );
    }

    getRoles() {
        const data = {
            idRolUser: this.userData.role_id
        };

        this.usersService.getRolesByUser(data).subscribe(
            (resp: any) => {
                if (resp.status === 200) {
                    this.roleOptions = resp.data;
                    this.filteredRole.next(this.roleOptions.slice());
                    this.setRole();
                } else {
                    this.objToastrService.error('Error consultando los registros', 'ERROR:');
                }
            }, () => {
                this.objToastrService.error('Error consultando los registros', 'ERROR:');
            }
        );
    }

    setRole() {
        if (this.data['role'] !== null) {
            this.roleCtrl.setValue(this.data['role'].id);
        }
    }

    save() {
        if (this.roleCtrl.invalid) {
            this.objToastrService.warning('Debe seleccionar un rol', 'ALERTA:');
        } else {
            const params = {
                idUser: this.data['user'],
                idRol: this.roleCtrl.value
            };

            this.usersService.assignRole(params).subscribe(
                (resp: any) => {
                    if (resp.status === 200) {
                        this.objToastrService.success('Registro guardado exitosamente.', 'EXITO');
                        this.dialogRef.close('ok');
                        location.reload();
                    } else {
                        this.objToastrService.error('Error guardando el registro.', 'ERROR:');
                    }
                }, () => {
                    this.objToastrService.error('Error guardando el registro.', 'ERROR:');
                }
            )
        }
    }
}