import { CreateEditCategoryComponent } from './modals/create-edit/create-edit-category.component';
import { CategoryService } from './../../service/category.service';
import { AlertService } from './../../service/utils/alert.service';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { TokenService } from './../../service/utils/token.service';
import { AreasService } from './../../service/areas.service';
import { Component, OnInit, ViewChild } from "@angular/core";
import { MatPaginator } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { ToastrService } from 'ngx-toastr';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;

@Component({
    selector: 'app-categories',
    templateUrl: './categories.component.html',
    styleUrls: ['./categories.component.scss']
})
export class CategoriesComponent implements OnInit {
    public dataSource = new MatTableDataSource<any>([]);
    public searchResult: boolean = false;
    public emptyData: boolean = false;
    public preloader: boolean;
    public userData: any;
    public areas: [];
    public area: number;
    public showAreas: boolean = false;

    @ViewChild(MatPaginator, {static: true}) public paginator: MatPaginator;
    @ViewChild(MatSort, {static: true}) public sort: MatSort;

    public displayedColumns: string[] = [
        'actions',
        'name',
        'created_by',
        'created_at',
        'updated_by',
        'updated_at',
        'responsibles',
        'supervisors',
        'status'
    ];

    constructor(
        private dialog: MatDialog,
        private alertService: AlertService,
        private objToastrService: ToastrService,
        private categoryService: CategoryService,
        private tokenService: TokenService,
        private areaService: AreasService,
    ) {}

    ngOnInit() {
        this.getDataUser();
        this.getAreas();
    }

    getCategories(area: number) {
        this.preloader = true;

        const params = {
            idArea: area
        };

        this.categoryService.getAll(params).subscribe((response: any) => {
                if (response.status === 200) {
                    this.setDataCategories(response.data);
                } else {
                    this.objToastrService.error('ERROR');
                }
                this.preloader = false;
            }, () => {
                this.objToastrService.error('ERROR');
                this.preloader = false;
            }
        );
    }

    getAreas() {
        this.areaService.getAll().subscribe((res: any) => {
            if (res.status === 200) {
                this.areas = res.data.filter(
                    (area) => area.deleted === 0
                );
            } else {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    areaByUser() {
        if (this.userData.role_id === ROL_AUDITOR) {
            this.getCategories(this.area);
        }
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            if (this.userData.role_id === ROL_ADMIN) {
                this.getCategories(this.userData.area_id);
            } else if (this.userData.role_id === ROL_AUDITOR) {
                this.showAreas = true;
            }
        }, () => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    setDataCategories(data){
        this.dataSource = new MatTableDataSource<any>(data);
        this.dataSource.paginator = this.paginator;
        this.dataSource.filterPredicate = function(data, filter: string): boolean {
            if (data.name) {
              return data.name.toLowerCase().includes(filter);
            }
        };
        if (this.dataSource.data.length === 0 && this.searchResult) {
            this.emptyData = true;
        }
        this.preloader = false;
    }

    save(category = {name: '', response_time: '', id: null, active: ''}) {
        let title = 'Crear';
        if (category.id) {
            title = 'Editar'
        }
        const dialogRef = this.dialog.open(CreateEditCategoryComponent, {
            data: {
                category,
                title: title
            },
            width: '300px',
            disableClose: true
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result === 'ok') {
                    this.ngOnInit();
                    this.areaByUser();
                }
            }
        );
    }

    deleteCategory(id) {
        this.alertService.confirm(
            '<h1>Eliminar categoria</h1>',
            '¿Esta seguro que desea eliminar la categoria?',
            'question'
        ).then(
            res => {
                if (res) {
                    const params = {idCategory: id};
                    this.categoryService.delete(params).subscribe(
                        (response: any) => {
                            if (response.status === 200) {
                                this.objToastrService.success('Registro eliminado correctamente.', 'EXITO:');
                                this.ngOnInit();
                                this.areaByUser();
                            } else {
                                this.objToastrService.error(response.msm, 'ERROR:');
                            }
                        }
                    );
                }
            }
        );
    }

    /**
     * @date(28-05-2020)
     * @author Kevin Londoño Benitez <kevin.londono@grupokonecta.com>
     * @description Metodo para filtrar la información de la tabla
     * @param filterValue  Texto por le cual se filtrará
    **/
    applyFilter(filterValue: string) {
        filterValue = filterValue.trim();
        filterValue = filterValue.toLowerCase();
        this.dataSource.filter = filterValue;
    }

}
