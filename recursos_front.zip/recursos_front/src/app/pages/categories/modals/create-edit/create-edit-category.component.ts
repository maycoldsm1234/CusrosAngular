import { takeUntil } from 'rxjs/operators';
import { ReplaySubject, Subject } from 'rxjs';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { CategoryService } from './../../../../service/category.service';
import { Component, Inject, OnInit } from "@angular/core";
import { UsersService } from './../../../../service/users.service'
import { TokenService } from './../../../../service/utils/token.service';


@Component({
    selector: 'app-create-edit-category',
    templateUrl: './create-edit-category.component.html',
    styleUrls: ['./create-edit-category.component.scss']
})
export class CreateEditCategoryComponent implements OnInit{
    public categoryForm: FormGroup;
    public preloader: boolean;
    public title: string;
    public userData: any;

    public formData = new FormData();

    public status = [
        {id: 1, label: 'Activa'},
        {id: 0, label: 'Inactiva'}
    ];

    public users = [];

    public supervisorsSearch = new FormControl();
    protected supervisorsDestroy = new Subject<void>();
    public filteredSupervisors = new ReplaySubject<any[]>(1);

    public responsibleSearch = new FormControl();
    protected responsibleDestroy = new Subject<void>();
    public filteredResponsible = new ReplaySubject<any[]>(1);

    constructor(
        private categoryService: CategoryService,
        private usersService: UsersService,
        private objToastrService: ToastrService,
        private formBuilder: FormBuilder,
        private tokenService: TokenService,
        private dialogRef: MatDialogRef<CreateEditCategoryComponent>,
        @Inject(MAT_DIALOG_DATA) public data: any
    ) {}

    ngOnInit() {
        this.title = this.data['title'];
        this.getDataUser();
        this.buildForm();
        this.searchChanged();
    }

    searchChanged() {
        this.supervisorsSearch.valueChanges
            .pipe(takeUntil(this.supervisorsDestroy))
            .subscribe(() => {
                this.filterSupervisors();
            }
        );

        this.responsibleSearch.valueChanges
            .pipe(takeUntil(this.responsibleDestroy))
            .subscribe(() => {
                this.filterResponsible();
            }
        );
    }

    filterSupervisors() {
        if (!this.users) {
            this.filteredSupervisors.next(this.users.slice());
            return;
        }

        let search = this.supervisorsSearch.value;

        if (!search) {
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredSupervisors.next(
            this.users.filter(option => option.name
                                        .toLowerCase()
                                        .indexOf(search) > -1)
        );
    }

    filterResponsible() {
        if (!this.users) {
            this.filteredResponsible.next(this.users.slice());
            return;
        }

        let search = this.responsibleSearch.value;

        if (!search) {
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredResponsible.next(
            this.users.filter(option => option.name
                                        .toLowerCase()
                                        .indexOf(search) > -1)
        );
    }

    buildForm() {
        let supervisors = [];
        let responsible = [];
        if(this.data['category'].id){
            const supervisorsArr = this.data['category'].users.filter(user => user.pivot.user_type_id === 1);
            const responsibleArr = this.data['category'].users.filter(user => user.pivot.user_type_id === 2);
            supervisorsArr.forEach(element => {
                supervisors.push(element.id);
            });

            responsibleArr.forEach(element => {
                responsible.push(element.id);
            });
        }
        this.categoryForm = this.formBuilder.group({
            name: new FormControl(this.data['category'].name, Validators.required),
            active: new FormControl(this.data['category'].active),
            supervisors:[supervisors],
            responsible: [responsible]
        });
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            this.setDataUsers(this.userData.area_id);
        }, (error) => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    setDataUsers(area){
        const params = {
            idArea: area
        };

        this.usersService.getUsers(params).subscribe(
            (response: any) => {
                if (response.status === 200) {
                    this.users = response.data;
                    this.filteredSupervisors.next(this.users.slice());
                    this.filteredResponsible.next(this.users.slice());
                } else {
                    this.objToastrService.error('Error listando los usuarios.', 'ERROR:');
                }
                this.preloader = false;
            }, () => {
                this.objToastrService.error('Error listando los usuarios.', 'ERROR:');
                this.preloader = false;
            }
        );
    }

    save() {
        if (this.categoryForm.invalid) {
            this.objToastrService.warning('Debe llenar todos los campos.', 'ALERTA:');
        } else {
            this.preloader = true;
            let category = this.categoryForm.value;

            if (this.data['category'].id) {
                category = {
                    ...category,
                    idCategory: this.data['category'].id
                };
            }

            this.categoryService.save(category).subscribe(
                (response: any) => {
                    if(response.data === 'EXIST_CATEGORY'){
                        this.objToastrService.warning('La categoría ya se encuentra registrada.', 'ALERTA:');
                    }else if (response.status === 200) {
                        this.objToastrService.success('Registros guardados exitosamente.', 'EXITO:');
                        this.dialogRef.close('ok');
                    } else {
                        this.objToastrService.error('Error guardando los registros.', 'ERROR:');
                    }
                    this.preloader = false;
                }, () => {
                    this.objToastrService.error('Error guardando los registros.', 'ERROR:');
                    this.preloader = false;
                }
            );
        }
    }
}