import { Component, OnInit, Input } from '@angular/core';
import { FormGroup, FormControl, FormBuilder, Validators } from '@angular/forms';
import { DateFilter } from 'src/app/model/date-filters.model';

@Component({
  selector: 'app-filter',
  templateUrl: './filter.component.html',
  styleUrls: ['./filter.component.scss']
})
export class FilterComponent implements OnInit {

  FilterGroupDate: FormGroup;

  dateFilter: DateFilter;

  startDateFormat: any;
  endDateFormat: any;


  constructor(
    private formBuilder: FormBuilder,
  ) { }

  ngOnInit() {
    this.filterFormControl();
    this.setDefaultRangeFilter();
    this.filterCases(this.FilterGroupDate.controls['startDate'].value, this.FilterGroupDate.controls['endDate'].value);
  }

  filterFormControl() {
    this.FilterGroupDate = this.formBuilder.group({
      startDate: new FormControl('', Validators.required),
      endDate: new FormControl('', Validators.required)
    });
  }

  setDefaultRangeFilter(){
    let endDate = new Date();
    let startDate = new Date();
    startDate.setMonth(endDate.getMonth() - 1);

    this.FilterGroupDate.controls['startDate'].setValue(startDate.toISOString().split('T')[0]);
    this.FilterGroupDate.controls['endDate'].setValue(endDate.toISOString().split('T')[0]);
  }

  filterCases(startDate, endDate) {
    var data = null;
    if(startDate && endDate) {
      this.startDateFormat = new Date(startDate).toISOString().split('T')[0];
      this.endDateFormat   = new Date(endDate).toISOString().split('T')[0];
      data = {
        startDateFormat: this.startDateFormat,
        endDateFormat: this.endDateFormat
      }
    }
  }

}
