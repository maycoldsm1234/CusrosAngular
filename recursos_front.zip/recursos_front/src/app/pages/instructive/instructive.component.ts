import { ToastrService } from "ngx-toastr";
import {
  FormGroup,
  FormBuilder,
  Validators,
  FormControl,
} from "@angular/forms";
import { Component, OnInit } from "@angular/core";
import { CategoryService } from "./../../service/category.service";
import { TokenService } from "src/app/service/utils/token.service";
import { InstructiveService } from 'src/app/service/instructive.service';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;

@Component({
  selector: "app-instructive",
  templateUrl: "./instructive.component.html",
})
export class InstructiveComponent implements OnInit {
  public categoryOptions: any[];
  public subcategoryOptions: any[];
  public allcategories: any[];

  public instructiveForm: FormGroup;
  public uploadFormatUserForm: FormGroup;
  public operativeModelForm: FormGroup;

  private formData = new FormData();
  public preloader: Boolean = false;
  private fileType = ["pdf", "jpg", "png", "jpeg", "xls", "xlsx"];
  public keyUserManual = 'USER_MANUAL';
  public keyUserUploadFormat = 'USER_UPLOAD';
  public keyOperativeManagementModel = 'OPERATIVE_MANAGEMENT';
  public keyTutorialAdmin = 'TUTORIAL_ADMIN';
  public keyTutorialUser = 'TUTORIAL_USER';

  public panelOpenState = false;

  private userData: any;

  public showUpload:boolean = false;

  constructor(
    private formBuilder: FormBuilder,
    private objToastrService: ToastrService,
    private instructiveService: InstructiveService,
    private categoryService: CategoryService,
    private tokenService: TokenService,
  ) {}

  ngOnInit() {
    this.getDataUser();
    this.buildForm();
  }

  buildForm() {
    this.instructiveForm = this.formBuilder.group({
      attachments: new FormControl("", Validators.required),
    });

    this.uploadFormatUserForm = this.formBuilder.group({
      attachments: new FormControl("", Validators.required),
    });

    this.operativeModelForm = this.formBuilder.group({
      attachments: new FormControl("", Validators.required),
    });

  }

  onSave() {
    if (this.instructiveForm.invalid) {
      this.objToastrService.warning("Debe llenar todos los campos.");
    } else {
      this.preloader = true;
      const params = this.prepareSave();
      console.log(params, 'datos a enviar', this.instructiveForm);
      this.instructiveService.saveInstructive(params).subscribe(
        (response: any) => {
          if (response.status !== 200) {
            this.objToastrService.error(
              "Error al cargar el manual.",
              "ERROR:"
            );
          } else {
            this.objToastrService.success(
              "Se almacenó el manual correctamente",
              "EXITO:"
            );
            this.instructiveForm.reset();
          }
          this.preloader = false;
        },
        (error) => {
          this.objToastrService.error("Error al cargar el manual.");
          this.preloader = false;
        }
      );
    }
  }

  prepareSave() {
    this.formData.append(
      "attachments",
      this.instructiveForm.get("attachments").value
    );

    this.formData.append("key", this.keyUserManual);
    return this.formData;
  }

  onSaveFormatUpload(){
    if (this.uploadFormatUserForm.invalid) {
      this.objToastrService.warning("Debe llenar todos los campos.");
    } else {
      this.preloader = true;
      const params = this.prepareSaveUploadUserFormat();
      console.log(params, 'datos a enviar', this.instructiveForm);
      this.instructiveService.saveInstructive(params).subscribe(
        (response: any) => {
          if (response.status !== 200) {
            this.objToastrService.error(
              "Error al cargar el formato.",
              "ERROR:"
            );
          } else {
            this.objToastrService.success(
              "Se almacenó el formato correctamente",
              "EXITO:"
            );
            this.uploadFormatUserForm.reset();
          }
          this.preloader = false;
        },
        (error) => {
          this.objToastrService.error("Error al cargar el formato.");
          this.preloader = false;
        }
      );
    }
  }

  prepareSaveUploadUserFormat() {
    this.formData.append(
      "attachments",
      this.uploadFormatUserForm.get("attachments").value
    );

    this.formData.append("key", this.keyUserUploadFormat);
    return this.formData;
  }

  onSaveOperativeModelForm(){
    if (this.operativeModelForm.invalid) {
      this.objToastrService.warning("Debe llenar todos los campos.");
    } else {
      this.preloader = true;
      const params = this.prepareSaveoperativeModelForm();
      this.instructiveService.saveInstructive(params).subscribe(
        (response: any) => {
          if (response.status !== 200) {
            this.objToastrService.error(
              "Error al cargar el modelo.",
              "ERROR:"
            );
          } else {
            this.objToastrService.success(
              "Se almacenó el modelo correctamente",
              "EXITO:"
            );
            this.operativeModelForm.reset();
          }
          this.preloader = false;
        },
        (error) => {
          this.objToastrService.error("Error al cargar el modelo.");
          this.preloader = false;
        }
      );
    }
  }

  prepareSaveoperativeModelForm() {
    this.formData.append(
      "attachments",
      this.operativeModelForm.get("attachments").value
    );

    this.formData.append("key", this.keyOperativeManagementModel);
    return this.formData;
  }

  // Función para el manejo de archivos
  handleFileInput(files: FileList) {
    this.instructiveForm.get("attachments").setErrors(null);
    this.operativeModelForm.get("attachments").setErrors(null);
    this.uploadFormatUserForm.get("attachments").setErrors(null);
    if (files.length > 0) {
      let numFile = 1;
      // Bandera para detener el ciclo en la primera validación erronea
      let flagFileType = true;
      Array.from(files).forEach((file) => {
        if (flagFileType) {
          var extFile = file.name
            .substr(file.name.lastIndexOf(".") + 1)
            .toLowerCase();
          if (this.fileType.find((type) => type === extFile)) {
            this.formData.append("attachments", file, file.name);
          } else {
            this.objToastrService.error("Tipo de archivo no valido", "ERROR:");
            flagFileType = false;
            this.instructiveForm.get("attachments").setValue(null);
            this.operativeModelForm.get("attachments").setValue(null);
          this.uploadFormatUserForm.get("attachments").setValue(null);
          }
        }
        if (file.size / 1024 > 4096) {
          this.objToastrService.error(
            "Capacidad de carga superada (Máximo 4mb)",
            "ERROR:"
          );
          this.instructiveForm.get("attachments").setValue(null);
          this.operativeModelForm.get("attachments").setValue(null);
          this.uploadFormatUserForm.get("attachments").setValue(null);
        }
      });
    }
  }

  getExtentionFile(str) {
    return str.substr(str.lastIndexOf(".") + 1);
  }

  getDataUser() {
    this.tokenService.getDataUserFromToken().subscribe(
      (res: any) => {
        this.userData = res;

        if (this.userData.role_id === ROL_ADMIN || this.userData.role_id === ROL_AUDITOR) {
          this.showUpload = true;
        }
      },
      (error) => {
        this.objToastrService.error("Error consultando los datos.", "ERROR:");
        localStorage.removeItem('resourceToken');
        location.reload();
      }
    );
  }

  dowloadUserManual(key){
    this.instructiveService.downloadInstructive(key);
  }
}
