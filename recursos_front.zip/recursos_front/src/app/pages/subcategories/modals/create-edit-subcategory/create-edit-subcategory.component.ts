import { Component, OnInit, Inject } from "@angular/core";
import {
  FormGroup,
  FormControl,
  FormBuilder,
  Validators,
} from "@angular/forms";
import { Subject, ReplaySubject } from "rxjs";
import { CategoryService } from "src/app/service/category.service";
import { UsersService } from "src/app/service/users.service";
import { ToastrService } from "ngx-toastr";
import { MatDialogRef, MAT_DIALOG_DATA } from "@angular/material";
import { takeUntil } from "rxjs/operators";
import { TimeService } from "src/app/service/time.service";
import { SubcategoriesService } from "src/app/service/subcategories.service";

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;
@Component({
  selector: "app-create-edit-subcategory",
  templateUrl: "./create-edit-subcategory.component.html",
  styleUrls: ["./create-edit-subcategory.component.scss"],
})
export class CreateEditSubcategoryComponent implements OnInit {
  public subcategoryForm: FormGroup;
  public preloader: boolean;
  public title: string;

  public formData = new FormData();

  public status = [
    { id: 1, label: "Activa" },
    { id: 0, label: "Inactiva" },
  ];
  
  public optionsResponseTime = [];
  
  public users = [];
  
  public categories = [];
  public areaCategorySelected:number;
  
  public supervisorsSearch = new FormControl();
  protected supervisorsDestroy = new Subject<void>();
  public filteredSupervisors = new ReplaySubject<any[]>(1);
  
  public responsibleSearch = new FormControl();
  protected responsibleDestroy = new Subject<void>();
  public filteredResponsible = new ReplaySubject<any[]>(1);
  
  public categoriesSearch = new FormControl();
  protected categoriesDestroy = new Subject<void>();
  public filteredCategories = new ReplaySubject<any[]>(1);
  
  
  constructor(
    private categoryService: CategoryService,
    private usersService: UsersService,
    private timeService: TimeService,
    private subcategoryService: SubcategoriesService,
    private objToastrService: ToastrService,
    private formBuilder: FormBuilder,
    private dialogRef: MatDialogRef<CreateEditSubcategoryComponent>,
    @Inject(MAT_DIALOG_DATA) public data: any
  ) {}

  ngOnInit() {
    this.title = this.data["title"];
    this.getCategories();
    this.searchChanged();  
    this.getTimes();
    this.buildForm();
  }

  getTimes() {
    this.timeService.getTime().subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.optionsResponseTime = response.data;
        } else {
          this.objToastrService.error(
            "Error al listar las categorías",
            "ERROR:"
          );
          this.preloader = false;
        }
      },
      () => {
        this.objToastrService.error("Error al listar las categorías", "ERROR:");
        this.preloader = false;
      }
    );
  }

  searchChanged() {
    this.categoriesSearch.valueChanges
      .pipe(takeUntil(this.categoriesDestroy))
      .subscribe(() => {
        this.filterCategories();
      });
  }

  onChangeCategory(value: any) {
    if (value != null && value != undefined && value != '') {
      const category = this.categories.filter(category => category.id === value);
      this.areaCategorySelected = category[0].area_id;
      this.setDataUsers(category[0].id);
    }
  }

  filterCategories() {
    if (!this.categories) {
      this.filteredCategories.next(this.categories.slice());
      return;
    }

    let search = this.categoriesSearch.value;

    if (!search) {
      return;
    } else {
      search = search.toLowerCase();
    }

    this.filteredCategories.next(
      this.categories.filter(
        (option) => option.name.toLowerCase().indexOf(search) > -1
      )
    );
  }

  filterSupervisors() {
    if (!this.users) {
      this.filteredSupervisors.next(this.users.slice());
      return;
    }

    let search = this.supervisorsSearch.value;

    if (!search) {
      return;
    } else {
      search = search.toLowerCase();
    }

    this.filteredSupervisors.next(
      this.users.filter(
        (option) => option.name.toLowerCase().indexOf(search) > -1
      )
    );
  }

  filterResponsible() {
    if (!this.users) {
      this.filteredResponsible.next(this.users.slice());
      return;
    }

    let search = this.responsibleSearch.value;

    if (!search) {
      return;
    } else {
      search = search.toLowerCase();
    }

    this.filteredResponsible.next(
      this.users.filter(
        (option) => option.name.toLowerCase().indexOf(search) > -1
      )
    );
  }

  buildForm() {
    this.subcategoryForm = this.formBuilder.group({
      idSubcategory: null,
      area_id: null,
      name: new FormControl('', Validators.required),
      responseTime: new FormControl('', Validators.required),
      active: new FormControl(''),
      category: new FormControl('', Validators.required),
      supervisors: new FormControl('', Validators.required),
      responsible: new FormControl('', Validators.required),
    });

    this.setFormSubcategoryForm();
  }

  setFormSubcategoryForm() {
    if (this.data["subcategory"].id) {
      this.subcategoryForm.controls["name"].setValue(
        this.data["subcategory"].name
      );
      this.subcategoryForm.controls["responseTime"].setValue(this.data["subcategory"].response_time_id);
      this.subcategoryForm.controls["category"].setValue(this.data["subcategory"].category_related.id);
      this.subcategoryForm.controls["active"].setValue(this.data["subcategory"].active);
    }
  }

  getCategories() {
    if(this.data["subcategory"].area_id){
      let params = {
        idArea : this.data["subcategory"].area_id
      }

      this.categoryService.getAll(params).subscribe((response: any) => {
        if (response.status === 200) {
          this.categories = response.data;
          let category = response.data.filter(
            (category) => category.category_id === null && category.active == 1
          );
          if(this.data["subcategory"].role_id != undefined && 
              this.data["subcategory"].role_id === ROL_ADMIN){
            category.filter(
              (category) => category.area_id == this.data["subcategory"].area_id && category.active == 1
            );
          }
          this.categories = category;
          if(this.data["subcategory"].id){
            this.subcategoryForm.get('category').setValue(this.data["subcategory"].category_related.id);
            this.loadDataUsers();
          }
          this.filteredCategories.next(this.categories.slice());
        } else {
          this.objToastrService.error(
            "Error al listar las categorías",
            "ERROR:"
          );
        }
        this.preloader = false;
    },
    () => {
      this.objToastrService.error("No se pudieron consultar las categorías", "ERROR:");
      this.preloader = false;
    });
  }
}

  loadDataUsers(){
    let supervisors = [];
    let responsible = [];

    if (this.data["subcategory"].id) {
      const supervisorsArr = this.data["subcategory"].users.filter(
        (user) => user.pivot.user_type_id === 1
      );
      const responsibleArr = this.data["subcategory"].users.filter(
        (user) => user.pivot.user_type_id === 2
      );
      supervisorsArr.forEach((element) => {
        supervisors.push(element.id);
      });

      responsibleArr.forEach((element) => {
        responsible.push(element.id);
      });

      this.subcategoryForm.get('supervisors').setValue(supervisors);
      this.subcategoryForm.get('responsible').setValue(responsible);
    }
  }

  removeDuplicates(originalArray, prop) {
    var newArray = [];
    var lookupObject  = {};

    for(var i in originalArray) {
       lookupObject[originalArray[i][prop]] = originalArray[i];
    }

    for(i in lookupObject) {
        newArray.push(lookupObject[i]);
    }
     return newArray;
}

  setDataUsers(idCategory) {
    let params = {
      idCategory : idCategory
    }
    this.usersService.getUsersByCategory(params).subscribe(
      (response: any) => {
        if (response.status === 200) {
          this.users =  response.data;

          
          const supervisorsArr = response.data.filter(
            (user) => user.user_type_id === 1
            );

          const responsibleArr = response.data.filter(
            (user) => user.user_type_id === 2
            );
              
          this.filteredSupervisors.next(supervisorsArr.slice());
          this.filteredResponsible.next(responsibleArr.slice());

          this.supervisorsSearch.valueChanges
            .pipe(takeUntil(this.supervisorsDestroy))
            .subscribe(() => {
              this.filterSupervisors();
            });

          this.responsibleSearch.valueChanges
            .pipe(takeUntil(this.responsibleDestroy))
            .subscribe(() => {
              this.filterResponsible();
            });
        } else {
          this.objToastrService.error("Error listando los usuarios.", "ERROR:");
        }
        this.preloader = false;
      },
      () => {
        this.objToastrService.error("Error listando los usuarios.", "ERROR:");
        this.preloader = false;
      }
    );
  }

  save() {
    if (this.subcategoryForm.invalid) {
      this.objToastrService.warning("Debe llenar todos los campos.", "ALERTA:");
    } else {
      if (this.data["subcategory"].id) {
        this.subcategoryForm.get("idSubcategory").setValue(this.data["subcategory"].id);
      }

      if(this.areaCategorySelected != null){
        this.subcategoryForm.get("area_id").setValue(this.areaCategorySelected);
      }
      
      let subcategory = this.subcategoryForm.value;
      this.subcategoryService
        .saveSubcategory(subcategory)
        .subscribe((response: any) => {

          if(response.data == 'EXIST_SUBCATEGORY'){
            this.objToastrService.warning('La subcategoría ya se encuentra registrada.', 'ALERTA:');
          }else if (response.status === 200) {
            this.objToastrService.success(
              "Registros guardados exitosamente.",
              "EXITO:"
            );
            this.dialogRef.close("ok");
          } else {
            this.objToastrService.error(
              "Error guardando los registros.",
              "ERROR:"
            );
          }
          this.preloader = false;
        });
    }
  }
}
