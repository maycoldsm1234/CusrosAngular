import { Component, OnInit, ViewChild } from "@angular/core";
import {
  MatTableDataSource,
  MatPaginator,
  MatSort,
  MatDialog,
} from "@angular/material";
import { SubcategoriesService } from "src/app/service/subcategories.service";
import { ToastrService } from "ngx-toastr";
import { AlertService } from "src/app/service/utils/alert.service";
import { CreateEditSubcategoryComponent } from './modals/create-edit-subcategory/create-edit-subcategory.component';
import { TokenService } from 'src/app/service/utils/token.service';
import { AreasService } from 'src/app/service/areas.service';
import { CategoryService } from 'src/app/service/category.service';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;
@Component({
  selector: "app-subcategories",
  templateUrl: "./subcategories.component.html",
  styleUrls: ["./subcategories.component.scss"],
})
export class SubcategoriesComponent implements OnInit {
  public dataSource = new MatTableDataSource<any>([]);
  public searchResult: boolean = false;
  public emptyData: boolean = false;
  public preloader: boolean;

  public displayedColumns: string[] = [
    "actions",
    "name",
    "category",
    "response_time",
    "created_by",
    "created_at",
    "updated_by",
    "updated_at",
    "responsibles",
    "supervisors",
    "status",
  ];

  @ViewChild(MatPaginator, { static: true }) public paginator: MatPaginator;
  @ViewChild(MatSort, { static: true }) public sort: MatSort;
  public showCategories:boolean = false;
  public showGerencia:boolean = false;
  public userData: any;
  public area :any;
  public areasOptions:[];
  public categories:[];
  public categoryOptions:[];
  public roleId:any;

  constructor(
    private dialog: MatDialog,
    private alertService: AlertService,
    private subCategoriesService: SubcategoriesService,
    private objToastrService: ToastrService,
    private tokenService: TokenService,
    private areaService:AreasService,
    private categoryService:CategoryService,
  ) {}

  ngOnInit() {
    this.getDataUser();
  }

  getDataUser() {
    this.tokenService.getDataUserFromToken().subscribe((res: any) => {
        this.userData = res;
        this.roleId = this.userData.role_id;
        if (this.userData.role_id === ROL_ADMIN) {
          this.getCategories(this.userData.area_id);
        } else if (this.userData.role_id === ROL_AUDITOR) {
            this.showGerencia = true;
            this.getAreas();
        }
    }, (error) => {
        this.objToastrService.error('Error consultando los datos.', 'ERROR:');
        localStorage.removeItem('resourceToken');
        location.reload();
    });
}

      getCategories(area) {

        const params = {
          idArea: area
        };

        this.categoryService.getAll(params).subscribe((response: any) => {
                if (response.status === 200) {
                  this.categories = response.data;
                  let category = response.data.filter(
                    (category) => category.category_id === null
                  );
                  if(this.userData.role_id === ROL_ADMIN){
                    let categoryAd = response.data.filter(
                      (category) => category.area_id = this.userData.area_id && category.active == 1
                    );
                    category = categoryAd;
                  }
                  if(category.length>0){
                    this.showCategories = true;
                  }
                  this.categoryOptions = category;
                } else {
                    this.objToastrService.error('ERROR');
                }
                this.preloader = false;
            }, () => {
                this.objToastrService.error('ERROR');
            }
        );
      }

  getAreas(){
    this.areaService.getAll().subscribe((response : any) => {
      if(response.status == 200){
        this.areasOptions = response.data.filter(
          (area) => area.deleted === 0
      );
      }else{
        this.objToastrService.error('Error consultando los datos.', 'ERROR:');
      }
    },
    () => {
      this.objToastrService.error("ERROR");
      this.preloader = false;
    }
    );
  }

  onChangeArea(value) {
    if (value != null) {
      const params = { id_Area: value };
      this.categoryService.getcategoryByAreaUser(params).subscribe(
        (response: any) => {
          if (response.status) {
            
            this.categories = response.data;
            const category = response.data.filter(
              (category) => category.category_id === null && category.active == 1
            );
            if(category.length>0){
              this.showCategories = true;
            }
            this.categoryOptions = category;
          }
        },
        (error) => {
          this.objToastrService.error("Error al consultar las categorías.");
        }
      );
    }
  }

  onChangeSubcategories(value){
    if(value){
      this.getSubcategories(value);
    }
  }

  getSubcategories(idIntCategory) {
    this.preloader = true;
    let params = {
      idIntCategory : idIntCategory
    };

    this.subCategoriesService.getByCategory(params).subscribe(
      (response: any) => {
        if (response.status == 200) {
          this.setDataSubcategories(response.data);
        } else {
          this.objToastrService.error("ERROR");
        }
        this.preloader = false;
      },
      () => {
        this.objToastrService.error("ERROR");
        this.preloader = false;
      }
    );
  }

  setDataSubcategories(data) {
    this.dataSource = new MatTableDataSource<any>(data);
    this.dataSource.paginator = this.paginator;
    this.dataSource.filterPredicate = function (data, filter: string): boolean {
      if (data.name) {
        return data.name.toLowerCase().includes(filter);
      }
    };
    if (this.dataSource.data.length === 0 && this.searchResult) {
      this.emptyData = true;
    }
    this.preloader = false;
  }

  save(subcategory = { name: "", response_time: "", id: null, active: "", category: null, area_id: this.userData.area_id, role_id: this.roleId}) {
    let title = "Crear";
    if (subcategory.id) {
      title = "Editar";
    }
    const dialogRef = this.dialog.open(CreateEditSubcategoryComponent, {
      data: {
        subcategory,
        title: title,
      },
      width: "300px",
      disableClose: true,
    });

    dialogRef.afterClosed().subscribe((result) => {
      if (result === "ok") {
        this.dataSource = new MatTableDataSource<any>([]);
        this.clearInputs();
        this.ngOnInit();
      }
    });
  }

  clearInputs(){
    this.dataSource = new MatTableDataSource<any>([]);
    this.area = undefined;
    this.areasOptions = undefined;
    this.categoryOptions = undefined;
  }

  applyFilter(filterValue: string) {
    filterValue = filterValue.trim();
    filterValue = filterValue.toLowerCase();
    this.dataSource.filter = filterValue;
  }

  deleteSubcategory(id) {
    this.alertService
      .confirm(
        "<h1>Eliminar subcategoría</h1>",
        "¿Esta seguro que desea eliminar la subcategoría?",
        "question"
      )
      .then((res) => {
        if (res) {
          const params = { idSubcategory: id };
          this.subCategoriesService.deleteSubcategory(params).subscribe((response: any) => {
            if (response.status === 200) {
              this.objToastrService.success(
                "Registro eliminado correctamente.",
                "EXITO:"
              );
              this.clearInputs();
              this.ngOnInit();
            } else {
              this.objToastrService.error(response.msm, "ERROR:");
            }
          });
        }
      });
  }
}
