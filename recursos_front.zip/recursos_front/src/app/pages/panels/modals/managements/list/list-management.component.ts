import { AttachmentsService } from './../../../../../service/utils/attachments.service';
import { ManagementService } from './../../../../../service/management.service';
import { MatPaginator } from '@angular/material/paginator';
import { PanelsService } from './../../../../../service/panels.service';
import { FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA, MatTableDataSource } from '@angular/material';
import { Component, OnInit, Inject, ViewChild } from "@angular/core";
import { ModalDismissReasons, NgbModal } from '@ng-bootstrap/ng-bootstrap';

@Component({
    selector: 'app-list-management',
    templateUrl: './list-management.component.html',
    styleUrls: ['./list-management.component.scss']
})
export class ListManagementComponent implements OnInit {
    public preloader: boolean = false;
    public dataSource = new MatTableDataSource([]);

    public paginatorLength: number;
    private flagPaginator: boolean = true;
    public searchResult: boolean = false;
    public emptyData: boolean = false;

    public managementsData: any[];

    public description_modal = '';

    public displayedColumns: string[] = [
        'attached',
        'type_management',
        'state',
        'created_at',
        'user',
        'observation',
        'notify'
    ];

    @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

    constructor(
        @Inject(MAT_DIALOG_DATA) private data: any,
        private objToastrService: ToastrService,
        private managementServcie: ManagementService,
        private attachmentsService: AttachmentsService,
        private modalService: NgbModal
    ) {}

    ngOnInit() {
        this.getData();
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para consultar los datos de las gestiones de una solicitud
     */
    private getData() {
        this.preloader = true;

        this.managementServcie.getManagements(this.data['id']).subscribe(
            (resp) => {
                if (resp.status === 200) {
                    const managementsData: any[] = [];
                    this.objToastrService.success('Registros consultados exitosamente.', 'EXITO:');
                    resp.data.forEach(element => {
                        
                        if(element.observation != null && element.observation.length > 25){
                            var observation_short = element.observation.slice(0, 25);
                            var str_concat = '...';
                            var result_str = observation_short.toString() + str_concat.toString();
                        }else{
                            var observation_short = element.observation;
                        }

                        let notify;
                        if (element.notify === 1) {
                            notify = 'Si';
                        } else {
                            notify = 'No';
                        }
                        let attached = false;
                        if (element.attachments[0] !== undefined) {
                            attached = element.attachments[0].path;
                        }
                        managementsData.push({
                            type_management: element.type_management.description,
                            state: element.state.name,
                            created_at: element.created_at,
                            user: element.creation_user.name,
                            observation: (element.observation) ? (element.observation) : '',
                            notify,
                            attached,
                            observation_short: (result_str != null) ? result_str : observation_short,
                        });
                    });
                    this.setData(managementsData);
                } else {
                    this.objToastrService.error('Error consultado los registros.', 'ERROR:');
                }
                this.preloader = false;
            }, (error) => {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
                this.preloader = false;
                this.emptyData = true;
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para construir la tabla con los datos obtenidos de las gestiones
     * @param {Array} data Contiene todas las gestiones obtenidas de la API
     */
    private setData(data: any[]) {
        this.dataSource = new MatTableDataSource<any>(data);
        this.dataSource.paginator = this.paginator;

        if (this.dataSource.data.length === 0 && this.searchResult) {
            this.emptyData = true;
        }

        this.preloader = false;
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para descargar archivos adjuntos
     * @param {string} path Recibe el nombre del archivo a descargar
     */
    downloadAttached(path: string) {
        this.attachmentsService.downloadAttached(path);
    }


    open(content, element) {
        this.description_modal = element.observation;
        this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        }, (reason) => {

    
        });
    
      }

    private getDismissReason(reason: any): string {
    
        if (reason === ModalDismissReasons.ESC) {
    
          return 'by pressing ESC';
    
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    
          return 'by clicking on a backdrop';
    
        } else {
    
          return  `with: ${reason}`;
    
        }
    
      }
}