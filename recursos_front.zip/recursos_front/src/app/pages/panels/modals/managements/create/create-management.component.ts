import { ManagementService } from './../../../../../service/management.service';
import { StatesService } from './../../../../../service/states.service';
import { FormGroup, FormBuilder, FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { Component, Inject, OnInit } from '@angular/core';

@Component({
    selector: 'app-create-management',
    templateUrl: './create-management.component.html',
    styleUrls: ['./create-management.component.scss']
})
export class CreateManagementComponent implements OnInit {
    public createForm: FormGroup;
    public statusOptions: any[];
    public preloader: boolean;

    private fileType = ['pdf', 'jpg', 'png', 'jpeg'];
    private formData = new FormData();

    public category = new FormControl(this.data['category']);
    public status = new FormControl(this.data['status']);
    public description = new FormControl(this.data['description']);
    public attachments = new FormControl();

    constructor(
        private dialogRef: MatDialogRef<CreateManagementComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private objToasrService: ToastrService,
        private formBuilder: FormBuilder,
        private statesService: StatesService,
        private managementService: ManagementService
    ) {}

    ngOnInit() {
        this.buildForm();
        this.getStatesOptions();
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para construir el formulario
     */
    buildForm() {
        this.createForm = this.formBuilder.group({
            state: new FormControl('', Validators.required),
            notify: new FormControl(false, Validators.required),
            observation: new FormControl('', Validators.required)
        });
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para consultar los estados disponibles en la base de datos.
     */
    getStatesOptions() {
        this.statesService.getStates().subscribe(
            (response) => {
                if (response.status) {
                    this.statusOptions = response.data;
                }
            }, (error) => {
                console.error(error);
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para validar la información llenada en el formulario de creacion y edicion
     * y posterior consumo de API para editar o guardar la información.
     */
    save() {
        if (this.createForm.invalid) {
            this.objToasrService.warning('Debe llenar todos los campos.', 'ALERTA:');
        } else {
            this.preloader = true;
            this.prepareSave();

            this.managementService.saveManagement(this.formData).subscribe(
                (response) => {
                    if (response.status === 500) {
                        this.objToasrService.error('Error al guardar la información.', 'ERROR:');
                    } else {
                        const result = {
                            message: 'ok',
                            panelTypeDefault: this.data['panelTypeDefault'],
                            categoryDefault: this.data['categoryDefault']
                        };
                        this.objToasrService.success('Registro guardado exitosamente.', 'EXITO:');
                        this.dialogRef.close(result);
                    }
                    this.preloader = false;
                }, (error) => {
                    this.objToasrService.error('Error al guardar la información.', 'ERROR:');
                    this.preloader = false;
                }
            );
        }
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para capturar los datos del formulario y agregarlos al formData
     */
    prepareSave() {
        let params = this.createForm.value;
        params = {
            ...params,
            idRequest: this.data['id']
        };

        this.formData.append('data', JSON.stringify(params));
    }

    handleFileInput(files: FileList) {
        this.attachments.setErrors(null);
        if (files.length > 0) {
            let flagFileType = true;
            Array.from(files).forEach(file => {
                if(flagFileType){
                    const extFile = file.name.substr(file.name.lastIndexOf('.') + 1).toLowerCase();
                    if (this.fileType.find(type => type === extFile)) {
                        this.formData.append('attachments', file, file.name);
                    } else {
                        this.objToasrService.error('Tipo de archivo no valido', 'ERROR:');
                        flagFileType = false;
                        this.attachments.setValue(null);
                    }
                }
                if ((file.size / 1024) > 4096) {
                    this.objToasrService.error('Capacidad de carga superada (Máximo 4mb)', 'ERROR:');
                    this.attachments.setValue(null);
                }
            });
        }
    }
}
