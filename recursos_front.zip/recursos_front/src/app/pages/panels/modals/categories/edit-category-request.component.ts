import { takeUntil } from 'rxjs/operators';
import { Subject, ReplaySubject } from 'rxjs';
import { FormControl, Validators } from '@angular/forms';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { Component, OnInit, Inject } from '@angular/core';
import { CategoryService } from 'src/app/service/category.service';
import { SubcategoriesService } from "src/app/service/subcategories.service";

@Component({
    selector: 'app-edit-category-request',
    templateUrl: './edit-category-request.component.html',
    styleUrls: ['./edit-category-request.component.scss']
})
export class EditCategoryRequestComponent implements OnInit {
    public categoriesOptions: any[] = [];
    public categoryCtrl = new FormControl('', Validators.required);
    public categorySearch = new FormControl();
    protected categoryDestroy = new Subject<void>();
    public filteredCategory = new ReplaySubject<any[]>(1);

    public preloader: boolean = false;

    constructor(
        private categoryService: CategoryService,
        private objToastrService: ToastrService,
        private subCategoriesService: SubcategoriesService,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private dialogRef: MatDialogRef<EditCategoryRequestComponent>
    ) {
        this.categoryCtrl.setValue(this.data['idCategory']);
    }

    ngOnInit() {
        this.getSubcategories();
        this.searchChanged();
    }

    searchChanged() {
        this.categorySearch.valueChanges
            .pipe(takeUntil(this.categoryDestroy))
            .subscribe(() => {
                this.filterCategory();
            }
        );
    }

    filterCategory() {
        if (!this.categoriesOptions) {
            return;
        }

        let search = this.categorySearch.value;

        if (!search) {
            this.filteredCategory.next(this.categoriesOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredCategory.next(
            this.categoriesOptions.filter(option => option.name
                                            .toLowerCase()
                                            .indexOf(search) > -1)
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para consultar todas las categorias
     */
    getSubcategories() {
        this.preloader = true;
        const params = {
            idIntCategory: this.data['subcategory']
        };

        this.subCategoriesService.getsubcategoryBycategory(params).subscribe(
            (response: any) => {
            if (response.status == 200) {
                this.categoriesOptions = response.data.filter(
                    (subcategory) => subcategory.active == 1
                  );
                this.filteredCategory.next(this.categoriesOptions.slice());
            } else {
                this.objToastrService.error("ERROR");
            }
            },
            () => {
            this.objToastrService.error("ERROR");
            }, () => {
                this.preloader = false;
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para guardar el cambio de categoría
     */
    save() {
        if (this.categoryCtrl.valid) {
            this.preloader = true;
            const params = {
                idRequest: this.data['idRequest'],
                idCategory: this.categoryCtrl.value
            };

            this.categoryService.setCategory(params).subscribe(
                (response: any) => {
                    if (response.status === 200) {
                        this.objToastrService.success('Categoria actualizada.', 'EXITO:');
                        this.dialogRef.close({
                            message: 'ok',
                            panelTypeDefault: this.data['panelTypeDefault'],
                            categoryDefault: this.data['categoryDefault']
                        });
                    } else {
                        this.objToastrService.error('Error actualizando la categoria.', 'ERROR:');
                    }
                }, () => {
                    this.objToastrService.error('Error actualizando la categoria.', 'ERROR:');
                }, () => {
                    this.preloader = false;
                }
            );
        } else {
            this.objToastrService.warning('Debe seleccionar una categoria.', 'ALERTA:');
        }
    }
}
