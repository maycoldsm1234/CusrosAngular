import { takeUntil } from 'rxjs/operators';
import { Subject, ReplaySubject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { FormControl, Validators } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { UsersService } from './../../../../service/users.service';
import { Component, OnInit, Inject } from '@angular/core';

@Component({
    selector: 'app-edit-assigned-request',
    templateUrl: './edit-assigned-request.component.html',
    styleUrls: ['./edit-assigned-request.component.scss']
})
export class EditAssignedRequestComponent implements OnInit {
    public usersOptions: any[] = [];
    public userCtrl = new FormControl('', Validators.required);
    public preloader: boolean = false;

    public userSearch = new FormControl();
    protected userDestroy = new Subject<void>();
    public filteredUsers = new ReplaySubject<any[]>(1);

    constructor(
        private usersService: UsersService,
        private objToastrService: ToastrService,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private dialogRef: MatDialogRef<EditAssignedRequestComponent>
    ) {
        this.userCtrl.setValue(this.data['idUser']);
    }

    ngOnInit() {
        this.getUsers();
        this.searchChanged();
    }
    
    searchChanged() {
        this.userSearch.valueChanges
            .pipe(takeUntil(this.userDestroy))
            .subscribe(() => {
                this.filterUsers();
            }
        );
    }

    filterUsers() {
        if (!this.usersOptions) {
            return;
        }

        let search = this.userSearch.value;

        if (!search) {
            this.filteredUsers.next(this.usersOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredUsers.next(
            this.usersOptions.filter(option => option.name
                                        .toLowerCase()
                                        .indexOf(search) > -1)
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para consultar todos los usuarios
     */
    getUsers() {
        this.preloader = true;
        const params = { idArea: this.data['idArea'] }
        this.usersService.getUsers(params).subscribe(
            (response: any) => {
                if (response.status === 200) {
                    this.usersOptions = response.data;
                    this.filteredUsers.next(this.usersOptions.slice());
                } else {
                    this.objToastrService.error('Error consultando los usuarios.', 'ERROR:');
                }
            }, () => {
                this.objToastrService.error('Error consultando los usuarios.', 'ERROR:');
            }, () => {
                this.preloader = false;
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para actualizar el usuario asignado
     */
    save() {
        if (this.userCtrl.valid) {
            this.preloader = true;
            const params = {
                idRequest: this.data['idRequest'],
                idUser: this.userCtrl.value
            };

            this.usersService.setAssigned(params).subscribe(
                (response: any) => {
                    if (response.status === 200) {
                        this.objToastrService.success('Usuario asignado actualizado.', 'EXITO:');
                        this.dialogRef.close({
                            message: 'ok',
                            panelTypeDefault: this.data['panelTypeDefault'],
                            categoryDefault: this.data['categoryDefault']
                        })
                    } else {
                        this.objToastrService.error('Error actualizando el usuario asignado.', 'EXITO:')
                    }
                }, () => {
                    this.objToastrService.error('Error actualizando el usuario asignado.', 'EXITO:')
                }, () => {
                    this.preloader = false;
                }
            );
        } else {
            this.objToastrService.warning('Debe seleccionar un usuario asignado.', 'ALERTA:');
        }
    }
}
