import { ListManagementComponent } from './modals/managements/list/list-management.component';
import { PanelsService } from './../../service/panels.service';
import { CategoryService } from './../../service/category.service';
import { Component, OnInit, ViewChild, Input } from '@angular/core';
import { FormControl } from '@angular/forms';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { MatPaginator, PageEvent } from '@angular/material/paginator';
import { MatSort } from '@angular/material/sort';
import { JwtHelperService } from "@auth0/angular-jwt";
import { TokenService } from './../../service/utils/token.service';
import { AreasService } from './../../service/areas.service';
import { SubcategoriesService } from "src/app/service/subcategories.service";
import { StatesService } from './../../service/states.service';

/* Modals */
import { ToastrService } from 'ngx-toastr';
import { FilterComponent } from '../home/filter/filter.component';
import { CreateManagementComponent } from './modals/managements/create/create-management.component';
import { EditCategoryRequestComponent } from './modals/categories/edit-category-request.component';
import { EditAssignedRequestComponent } from './modals/assigned/edit-assigned-request.component';

import {NgbModal, ModalDismissReasons} from '@ng-bootstrap/ng-bootstrap';

export const ROL_ADMIN: number = 1;
export const ROL_AUDITOR: number = 3;

@Component({
    selector: 'app-panels',
    templateUrl: './panels.component.html',
    styleUrls: ['./panels.component.scss']
})
export class PanelsComponent implements OnInit {

    @Input() filterComponent: FilterComponent;
    @ViewChild(MatSort, {static: true}) sort: MatSort;
    @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;

    panelType = [
        { id: 1, value: 'user', label: 'Creadas por mi' },
        { id: 2, value: 'assigned', label: 'Asignadas a mi' }
    ]

    categoriesOptions = [];

    public preloader: boolean = false;
    public showView: boolean = true;
    public showCreate: boolean = false;

    panelTitle = '';

    dataSource = new MatTableDataSource([]);
    panelTypeCtrl = new FormControl();
    categoryCtrl = new FormControl();
    
    pageEvent: PageEvent;
    paginatorLength: number;
    paginatorSize: number;
    paginatorOptions: number;

    flagPaginator = true;
    searchResult = false;
    emptyData = false;
    public areas: [];
    public states: [];
    public categories: [];
    public subcategories: [];
    // public subcategoryOptions: any;
    public area: number;
    public category: number;
    public subcategory: any;
    public state: [];
    public userData: any;
    public showAreas: boolean = false;
    public showCategories: boolean = false;
    public showSubcategories: boolean = false;
    public showStates: boolean = true;
    public showStates2: boolean = false;

    public formData = new FormData();
    public myRequestDisplayedColumns: string[] = [
        'actions',
        'request',
        'category',
        'createdBy',
        'assignedTo',
        'state',
        'description',
        'date',
    ];
    public categoryDisplayedColumns: string[] = [
        'actions',
        'request',
        'category',
        'createdBy',
        'assignedTo',
        'state',
        'description',
        'date',
    ];
    public assignedDisplayedColumns: string[] = [
        'actions',
        'request',
        'category',
        'createdBy',
        'assignedTo',
        'state',
        'description',
        'date',
    ];

    public displayedColumns: string[] = [];

    public description_modal = '';
    
    constructor(
        private dialog: MatDialog,
        private objToastrService: ToastrService,
        private panelsService: PanelsService,
        private categoryService: CategoryService,
        private tokenService: TokenService,
        private areaService: AreasService,
        private subCategoriesService: SubcategoriesService,
        private statesService: StatesService,
        private modalService: NgbModal
    ) {}

    ngOnInit() {
        if (this.panelTypeCtrl.value === null) {
            this.panelTypeCtrl.setValue(this.panelType[0]);
            this.getDataUser();
        }

        this.onChangePanelType();
        this.listCategories();
        this.getStates();
     }

    getDataToken(){
        let tokenUser     = localStorage.getItem("resourceToken");
        let objHelper     = new JwtHelperService();
        let dataToken = null;
        if(tokenUser){
            let objDataToken = objHelper.decodeToken(tokenUser);
            if(objDataToken){
                dataToken = objDataToken;
            }
        }
        return dataToken;
    }

    getDataUser() {
        this.tokenService.getDataUserFromToken().subscribe((res: any) => {
            this.userData = res;
            if (this.userData.role_id === ROL_ADMIN) {
                this.panelType.push({ id: 3, value: 'other', label: 'Categoría' });
            } else if (this.userData.role_id === ROL_AUDITOR) {
                this.panelType.push({ id: 4, value: 'other', label: 'Gerencia' });
            }
        }, (error) => {
            this.objToastrService.error('Error consultando los datos.', 'ERROR:');
            localStorage.removeItem('resourceToken');
            location.reload();
        });
    }

    getAreas() {
        this.areaService.getAll().subscribe((res: any) => {
            if (res.status === 200) {
                this.areas = res.data.filter(
                    (area) => area.deleted === 0
                );
            } else {
                this.objToastrService.error('Error consultando los registros.', 'ERROR:');
            }
        }, () => {
            this.objToastrService.error('Error consultando los registros.', 'ERROR:');
        });
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para cargar las columnas del tablero de control
     * dependiendo del tipo de tablero seleccionado
     */
    onChangePanelType() {
        this.showAreas = false;
        this.showCategories = false;
        this.showSubcategories = false;
        this.showView = true;
        this.showCreate = true;

        this.area = null;
        this.category = null;
        this.subcategory = null;
        this.state = [];
        this.panelTitle = this.panelTypeCtrl.value.label;

        switch (this.panelTypeCtrl.value.value) {
            case 'user':
                this.displayedColumns = this.myRequestDisplayedColumns;
                this.showView = true;
                this.showCreate = false;
                this.showStates = true;
                this.showStates2= false;
                break;
            case 'other':
                this.showStates = false;
                this.showStates2= false;
                if (this.panelTypeCtrl.value.id === 3) {
                    this.displayedColumns = this.categoryDisplayedColumns;
                    this.showCategories = true;
                    this.getCategories(this.userData.area_id);
                    this.setData([]);
                } else {
                    this.showAreas = true;
                    this.getAreas();
                    this.setData([]);
                }
                this.preloader = false;
                return;
            case 'assigned':
                this.showStates = true;
                this.showStates2= false;
                this.displayedColumns = this.assignedDisplayedColumns;
                break;
        }

        this.categoryCtrl.setValue(null);
        this.getPanelsData();
    }

    getCategories(area) {
        this.showCategories = true;
        this.category = null;
        this.subcategory = null;
        this.state = [];

        const params = {
            idArea: area
        };

        this.categoryService.getAll(params).subscribe((response: any) => {
                if (response.status === 200) {
                    this.categories = response.data.filter(
                        (category) => category.active === 1
                    );
                } else {
                    this.objToastrService.error('ERROR');
                }
                this.preloader = false;
            }, () => {
                this.objToastrService.error('ERROR');
            }
        );
    }

    getSubcategories(event) {
        this.showSubcategories = true;
        this.subcategory = null;
        this.state = [];

        const params = {
            idIntCategory: event
        };

        this.subCategoriesService.getsubcategoryBycategory(params).subscribe(
            (response: any) => {
            if (response.status == 200) {
                this.subcategories = response.data.filter(
                    (subcategory) => subcategory.active === 1
                  );
            } else {
                this.objToastrService.error("ERROR");
            }
            },
            () => {
            this.objToastrService.error("ERROR");
            }
        );
    }

    getStates() {
        this.showStates = true;
        this.showStates2= false;
        this.preloader = true;
        this.state = null;

        this.statesService.getAllStates().subscribe(
            (response) => {
                if (response.status === 200) {
                    this.states = response.data;
                } else {
                    this.objToastrService.error('Error consultado los registros', 'ERROR:');
                }
                this.preloader = false;
            }, () => {
                this.objToastrService.error('Error consultado los registros', 'ERROR:');
                this.preloader = false;
            }
        );
    }

    getRequest() {
        this.getPanelsData('request');
        this.showStates = true;
        this.showStates2= false;
        this.preloader = true;
    }

    getPanelsData(filter: any = 0) {
        this.flagPaginator = true;
        this.preloader = true;

        this.formData.delete('typeFilter');
        this.formData.delete('idFilter');
        this.formData.delete('subcategory');
        this.formData.delete('state');
        this.formData.delete('filter');

        let typeFilter = this.panelTypeCtrl.value.value;

        if (filter === 0) {
            let dataToken = this.getDataToken();
            this.formData.append('idFilter', dataToken.sub);
        } else {
            this.formData.append('idFilter', this.subcategory);
            this.showStates2= true;
            this.showStates= false;
            typeFilter = 'subcategory';
        }

        typeFilter = (typeFilter == 'other') ? 'subcategory' : typeFilter;
        
        this.formData.append('typeFilter', typeFilter);
        this.formData.append('state', JSON.stringify(this.state));

        this.panelsService.getPanelsData(this.formData).subscribe(
            (resp) => {
                if (resp.status) {
                    const data: any[] = [];
                    if (resp.data) {
                        resp.data.forEach(element => {

                            if(element.description.length > 25){
                                var description_short = element.description.slice(0, 25);
                                var str_concat = '...';
                                var result_str = description_short.toString() + str_concat.toString();
                            }else{
                                var description_short = element.description;
                            }
                            data.push({
                                id: element.id,
                                date: element.created_at,
                                category: element.category.name,
                                idCategory: element.category.id,
                                subcategory: element.category.category_id,
                                createdBy: (element.creation_user) ? element.creation_user.user_name : '',
                                assignedTo: (element.assigned_to) ? element.assigned_to.user_name : '',
                                idAssignedUser: (element.assigned_to) ? element.assigned_to.id : null,
                                state: element.state.name,
                                description: element.description,
                                description_short: (result_str != null) ? result_str : description_short,
                            });
                        });
                    }
                    this.setData(data);
                }
            }, (error) => {
                this.preloader = false;
                this.emptyData = true;
                this.objToastrService.error('Error consultado la información solicitada', 'ERROR:');
            }
        )
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para construir la tabla con su respectivo paginador
     * @param {Array} data Contiene los registros consultados de la API
     */
    setData( data: any[] ): void {
        this.dataSource = new MatTableDataSource<any>(data);
        this.paginatorLength = data.length;
        this.dataSource.filterPredicate = function(data, filter: string): boolean {
            if (data.id) {
                if(data.createdBy){
                    return data.id.toString().toLowerCase().includes(filter)  || 
                    data.createdBy.toLowerCase().includes(filter);
                } else {
                    return data.id.toString().toLowerCase().includes(filter);
                }
            }
        };
        if (this.flagPaginator) {
            this.dataSource.paginator = this.paginator;
            this.flagPaginator = false;
        }

        if (this.dataSource.data.length === 0 && this.searchResult) {
            this.emptyData = true;
        }
        this.preloader = false;
    }

    listCategories(){
        this.preloader = true;
        const dataToken =  this.getDataToken();
        const params = { idUser: dataToken.sub }
        this.categoryService.getCategoryByUser(params).subscribe((resp: any) => {
                if (resp.status) {
                    const categoryValue = this.categoryCtrl.value;
                    this.categoriesOptions = resp.data;
                    this.categoryCtrl.setValue(categoryValue);
                }
            }, (error) => {
                this.preloader = false;
                this.emptyData = true;
                this.objToastrService.error('Error consultado la información solicitada', 'ERROR:');
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para abrir el modal de listar gestiones.
     * @param {Number} id Contiene el id de la solicitud a consultar
     */
    showManagements(id) {
        const dialogRef = this.dialog.open(ListManagementComponent, {
            data: {
                id
            },
            disableClose: true,
            width: '800px'
        });
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para abrir el modal de crear gestión.
     * @param {Number} id Contiene el id de la solicitud a editar
     * @param {Number} category Contiene el id de la categoria de la solicitud
     * @param {Number} status Contiene el id del estado de la solicitud
     * @param {String} description Contiene la descripcion de la solicitud
     */
    createManagement(id, category, status, description) {
        const dialogRef = this.dialog.open(CreateManagementComponent, {
            data: {
                id,
                category,
                status,
                description,
                panelTypeDefault: this.panelType[0],
                categoryDefault: this.categoryCtrl.value
            },
            disableClose: true,
            width: '700px'
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result.message === 'ok') {
                    this.panelTypeCtrl.setValue(result.panelTypeDefault);
                    this.categoryCtrl.setValue(result.categoryDefault);
                    this.ngOnInit();
                }
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para abrir el modal de cambiar categoria
     * @param {Number} idRequest Id de la solicitud
     * @param {Number} idCategory Id de la categoria
     */
    changeCategory(idRequest, idCategory, subcategory) {
        const dialogRef = this.dialog.open(EditCategoryRequestComponent, {
            data: {
                idRequest,
                idCategory,
                subcategory,
                panelTypeDefault: this.panelType[0],
                categoryDefault: this.categoryCtrl.value
            },
            disableClose: true,
            width: '300px'
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result.message === 'ok') {
                    this.panelTypeCtrl.setValue(result.panelTypeDefault);
                    this.categoryCtrl.setValue(result.categoryDefault);
                    this.ngOnInit();
                }
            }
        );
    }

    /**
     * @date 21-05-2020
     * @author Andres Maldonado <andres.maldonado@grupokonecta.com>
     * @description Funcion para abrir el modal de cambiar el usuario asignado
     * @param {Number} idRequest Id de la solicitud
     * @param {Number} idUser Id del usuario asignado
     */
    changeAssigned(idRequest, idUser) {
        const dialogRef = this.dialog.open(EditAssignedRequestComponent, {
            data: {
                idRequest,
                idUser,
                idArea: this.userData.area_id,
                panelTypeDefault: this.panelType[0],
                categoryDefault: this.categoryCtrl.value
            },
            disableClose: true,
            width: '300px'
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result.message === 'ok') {
                    this.panelTypeCtrl.setValue(result.panelTypeDefault);
                    this.categoryCtrl.setValue(result.categoryDefault);
                    this.ngOnInit();
                }
            }
        );
    }

    /**
     * @date(28-05-2020)
     * @author Kevin Londoño Benitez <kevin.londono@grupokonecta.com>
     * @description Metodo para filtrar la información de la tabla
     * @param filterValue  Texto por le cual se filtrará
    **/
    applyFilter(filterValue: string) {
        filterValue = filterValue.trim();
        filterValue = filterValue.toLowerCase();
        this.dataSource.filter = filterValue;
    }

    open(content, element) {
        this.description_modal = element.description;
        this.modalService.open(content, {ariaLabelledBy: 'modal-basic-title'}).result.then((result) => {
        }, (reason) => {

    
        });
    
      }
    
      
    
      private getDismissReason(reason: any): string {
    
        if (reason === ModalDismissReasons.ESC) {
    
          return 'by pressing ESC';
    
        } else if (reason === ModalDismissReasons.BACKDROP_CLICK) {
    
          return 'by clicking on a backdrop';
    
        } else {
    
          return  `with: ${reason}`;
    
        }
    
      }
}
