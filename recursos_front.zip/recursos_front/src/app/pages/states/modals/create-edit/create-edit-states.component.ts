import { TokenService } from './../../../../service/utils/token.service';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { FormBuilder, FormGroup, Validators, FormControl } from '@angular/forms';
import { ToastrService } from 'ngx-toastr';
import { StatesService } from './../../../../service/states.service';
import { Component, Inject, OnInit } from "@angular/core";

@Component({
    selector: 'app-create-edit-states',
    templateUrl: './create-edit-states.component.html',
    styleUrls: ['./create-edit-states.component.scss']
})
export class CreateEditStatesComponent implements OnInit{
    public statesForm: FormGroup;
    public preloader: boolean;
    public title: string;

    public formData = new FormData();
    private objToken: any = {};

    constructor(
        private statesService: StatesService,
        private objToastrService: ToastrService,
        private formBuilder: FormBuilder,
        private dialogRef: MatDialogRef<CreateEditStatesComponent>,
        @Inject(MAT_DIALOG_DATA) private data: any,
        private tokenService: TokenService
    ) {
        this.objToken = this.tokenService.getDataToken();
    }

        ngOnInit() {
            this.title = this.data['title'];

            this.buildForm();
        }

        buildForm() {
            this.statesForm = this.formBuilder.group({
                name: new FormControl('', Validators.required)
            });

            this.setDataState();
        }

        setDataState() {
            if (this.data['state'] !== undefined) {
                this.statesForm.controls['name'].setValue(this.data['state'].name);
            }
        }

        save() {
            if (this.statesForm.invalid) {
                this.objToastrService.warning('Debe llenar todos los campos.', 'ALERTA:');
            } else {
                this.preloader = true;
                let state = this.statesForm.value;

                if (this.data['state'] !== undefined) {
                    state = {
                        ...state,
                        id: this.data['state'].id,
                        update_user_id: this.objToken.sub
                    };

                    const stateData = {
                        state
                    };

                    this.statesService.update(stateData).subscribe(
                        (response) => {
                            if (response.status === 200) {
                                this.objToastrService.success('Registros guardados exitosamente.', 'EXITO:');
                                this.dialogRef.close('ok');
                            } else {
                                this.objToastrService.error('Error guardando los registros.', 'ERROR:');
                            }
                            this.preloader = false;
                        }, () => {
                            this.objToastrService.error('Error guardando los registros.', 'ERROR:');
                            this.preloader = false;
                        }
                    );
                } else {
                    state = {
                        ...state,
                        creation_user_id: this.objToken.sub
                    }
                    const stateData = {
                        state
                    };

                    this.statesService.add(stateData).subscribe(
                        (response) => {
                            if (response.status === 200) {
                                this.objToastrService.success('Registros guardados exitosamente.', 'EXITO:');
                                this.dialogRef.close('ok');
                            } else {
                                this.objToastrService.error('Error guardando los registros.', 'ERROR:');
                            }
                            this.preloader = false;
                        }, () => {
                            this.objToastrService.error('Error guardando los registros.', 'ERROR:');
                            this.preloader = false;
                        }
                    );
                }
            }
        }
}