import { StatesService } from './../../service/states.service';
import { ToastrService } from 'ngx-toastr';
import { AlertService } from './../../service/utils/alert.service';
import { MatSort } from '@angular/material/sort';
import { MatPaginator } from '@angular/material/paginator';
import { MatTableDataSource, MatDialog } from '@angular/material';
import { Component, OnInit, ViewChild } from "@angular/core";
import { CreateEditStatesComponent } from './modals/create-edit/create-edit-states.component';

@Component({
    selector: 'app-states',
    templateUrl: './states.component.html',
    styleUrls: ['./states.component.scss']
})
export class StatesComponent implements OnInit {
    public dataSource = new MatTableDataSource<any>([]);
    public flagPaginator: boolean = true;
    public searchResult: boolean = false;
    public emptyData: boolean = false;
    public paginatorLength: number;
    public preloader: boolean;

    @ViewChild(MatPaginator, {static: true}) public paginator: MatPaginator;
    @ViewChild(MatSort, {static: true}) public sort: MatSort;

    public displayedColumns: string[] = [
        'actions',
        'name',
        'creationDate',
        'creation_user',
        'update_user',
        'updateDate',
    ];

    constructor(
        private dialog: MatDialog,
        private alertService: AlertService,
        private objToastrService: ToastrService,
        private statesService: StatesService
    ) {}

    ngOnInit() {
        this.getStates();
    }

    getStates() {
        this.preloader = true;

        this.statesService.getAllStates().subscribe(
            (response) => {
                if (response.status === 200) {
                    let states: any[] = [];
                    response.data.forEach(element => {
                        let creation_user = {};
                        let update_user = {};

                        if (element.creation_user !== null) {
                            creation_user = element.creation_user;
                        }

                        if (element.update_user !== null) {
                            update_user = element.update_user;
                        }

                        states.push({
                            id: element.id,
                            name: element.name,
                            updateDate: element.updated_at,
                            creationDate: element.created_at,
                            creation_user,
                            update_user
                        });
                    });

                    this.setData(states);
                } else {
                    this.objToastrService.error('Error consultado los registros', 'ERROR:');
                }
                this.preloader = false;
            }, () => {
                this.objToastrService.error('Error consultado los registros', 'ERROR:');
                this.preloader = false;
            }
        );
    }

    setData(data: any[]) {
        this.dataSource = new MatTableDataSource<any>(data);
        this.paginatorLength = data.length;
        this.dataSource.paginator = this.paginator;

        if (this.dataSource.data.length === 0 && this.searchResult) {
            this.emptyData = true;
        }

        this.preloader = false;
        this.objToastrService.success('Registros consultados exitosamente.', 'EXITO:');
    }

    editState(state) {
        const dialogRef = this.dialog.open(CreateEditStatesComponent, {
            data: {
                state,
                title: 'Editar'
            },
            width: '300px',
            disableClose: true
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result === 'ok') {
                    this.ngOnInit();
                }
            }
        );
    }

    addState() {
        const dialogRef = this.dialog.open(CreateEditStatesComponent, {
            data: {
                title: 'Crear'
            },
            width: '300px',
            disableClose: true
        });

        dialogRef.afterClosed().subscribe(
            (result) => {
                if (result === 'ok') {
                    this.ngOnInit();
                }
            }
        );
    }

    deleteState(id) {
        this.alertService.confirm(
            '<h1>Eliminar estado</h1>',
            '¿Esta seguro que desea eliminar el estado?',
            'question'
        ).then(
            res => {
                if (res) {
                    this.statesService.delete(id).subscribe(
                        (response) => {
                            if (response.status === 200) {
                                this.objToastrService.success('Registro eliminado correctamente.', 'EXITO:');
                                this.ngOnInit();
                            } else {
                                this.objToastrService.warning(response.msm, 'ALERTA:');
                            }
                        }, () => {
                            this.objToastrService.error('Error eliminando el registro.', 'ERROR:');
                        }
                    );
                }
            }
        );
    }
}
