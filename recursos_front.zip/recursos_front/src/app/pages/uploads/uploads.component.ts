import { Component, OnInit, ViewChild } from '@angular/core';
import { ToastrService } from 'ngx-toastr';
import { UsersService } from './../../service/users.service';
import { FormControl, FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'app-users',
  templateUrl: './uploads.component.html'
})
export class UploadsComponent implements OnInit {
    public preloader: boolean;
    public uploadsForm: FormGroup;
    private fileType = ['xlsx'];
    private formData = new FormData();

    constructor(
        private fb: FormBuilder, 
        private objToastrService: ToastrService, 
        private userService: UsersService
    ) { }

    ngOnInit() {
    }

    uploadFile(){
        this.preloader = true;
        this.userService.upload(this.formData).subscribe(res => {
            if(res.data){
                this.objToastrService.success('Archivo cargado correctamente', 'EXITO:');
            }else{
                this.objToastrService.error('Error cargando el archivo');
            }
            this.preloader = false;
        }, () => {
            this.objToastrService.error('Error cargando el archivo');
            this.preloader = false;
        });
    }

    handleFile(files: FileList, field){
        if (files.length > 0) {
            Array.from(files).forEach(file => {
                const extFile = file.name.substr(file.name.lastIndexOf(".")+1).toLowerCase();
                if (this.fileType.find(type => type === extFile)) {
                    this.formData.append(field, file);
                }else{
                    this.objToastrService.error('Tipo de archivo no valido', "ERROR:");
                    this.uploadsForm.get(field).setValue(null);
                }
            });
        }
    }

}
