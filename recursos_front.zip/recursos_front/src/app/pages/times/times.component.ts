import { Component, OnInit, ViewChild } from '@angular/core';
import { CreateEditComponent } from './modals/create-edit/create-edit.component';
import { TimeService } from './../../service/time.service';
import { ToastrService } from 'ngx-toastr';
import { AlertService } from './../../service/utils/alert.service';
import { MatTableDataSource, MatPaginator, MatSort, MatDialog } from '@angular/material';

@Component({
  selector: 'app-times',
  templateUrl: './times.component.html',
  styleUrls: ['./times.component.scss']
})
export class TimesComponent implements OnInit {
  public dataSource = new MatTableDataSource<any>([]);
  public paginatorLength: number;
  public flagPaginator: boolean;
  public searchResult: boolean;
  public emptyData: boolean;
  public preloader: boolean;

  @ViewChild(MatPaginator, {static: true}) paginator: MatPaginator;
  @ViewChild(MatSort, {static: true}) sort: MatSort;

  public displayedColumns: string[] = [
    'actions',
    'description',
    'value',
    'creationDate',
    'creation_user',
    'update_user',
    'updateDate',
];


  constructor(
    private timeService: TimeService,
    private dialog: MatDialog,
    private alertService: AlertService,
    private objToastrService: ToastrService
  ) { }

  ngOnInit() {
    this.getTime();
  }
  

  addTime() {
    const dialogRef = this.dialog.open(CreateEditComponent, {
      data: {
        title: 'Crear'
      },
      width: '700px',
      disableClose: true
    });

    dialogRef.afterClosed().subscribe(
      (result) => {
        if (result === 'ok') {
          this.ngOnInit();
        }
      }
    );
  }

  getTime() {
    this.preloader = true;

    this.timeService.getTime().subscribe(res => {
      if (res.status === 200) {
        const timesData: any[] = [];
        res.data.forEach(element => {
          let creation_user = '';
          let update_user = '';

          if (element.boss !== null) {
            creation_user = element.creation_user.user_name;
          }

          if (element.manager !== null) {
            update_user = element.update_user.user_name;
          }

          timesData.push({
            id: element.id,
            description: element.description,
            value: element.value,
            updateDate: element.updated_at,
            creationDate: element.created_at,
            creation_user,
            update_user
          });
        });
        this.setData(timesData);
      } else {
        this.preloader = false;
        this.emptyData = true;
        this.objToastrService.error('Error consultando los registros.', 'ERROR:');
      }
    }, () => {
      this.preloader = false;
      this.emptyData = true;
      this.objToastrService.error('Error consultando los registros.', 'ERROR:');
    });
  }

  setData(data: any[]) {
    this.dataSource = new MatTableDataSource<any>(data);
    this.paginatorLength = data.length;
    this.dataSource.paginator = this.paginator;

    if (this.dataSource.data.length === 0 && this.searchResult) {
        this.emptyData = true;
    }

    this.preloader = false;
    this.objToastrService.success('Registros consultados exitosamente.', 'EXITO:');
 }

editState(time) {
  const dialogRef = this.dialog.open(CreateEditComponent, {
      data: {
          time,
          title: 'Editar'
      },
      width: '600px',
      disableClose: true
  });

  dialogRef.afterClosed().subscribe(
      (result) => {
          if (result === 'ok') {
              this.ngOnInit();
          }
      }
  );
}

deleteState(id) {
  this.alertService.confirm(
      '<h1>Eliminar tiempo</h1>',
      '¿Esta seguro que desea eliminar el tiempo de respuesta?',
      'question'
  ).then(
      res => {
          if (res) {
              this.timeService.delete(id).subscribe(
                  (response) => {
                      if (response.status === 200) {
                          this.objToastrService.success('Registro eliminado correctamente.', 'EXITO:');
                          this.ngOnInit();
                      } else {
                          this.objToastrService.warning(response.msm, 'ALERTA:');
                      }
                  }, () => {
                      this.objToastrService.error('Error eliminando el registro.', 'ERROR:');
                  }
              );
          }
      }
  );
}

}
