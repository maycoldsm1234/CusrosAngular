
import { takeUntil } from 'rxjs/operators';
import { Subject, ReplaySubject } from 'rxjs';
import { MAT_DIALOG_DATA, MatDialogRef } from '@angular/material';
import { ToastrService } from 'ngx-toastr';
import { FormBuilder, FormGroup, FormControl, Validators } from '@angular/forms';
// import { UsersService } from './../../../../service/users.service';
import { TimeService } from './../../../../service/time.service';
import { Component, OnInit, Inject } from "@angular/core";
import { DIR_DOCUMENT } from '@angular/cdk/bidi';

@Component({
  selector: 'app-create-edit',
  templateUrl: './create-edit.component.html',
  styleUrls: ['./create-edit.component.scss']
})
export class CreateEditComponent implements OnInit {
    public timesForm: FormGroup;
    public preloader: boolean;
    public title: string;

    public bossOptions: any[] = [];
    public bossSearch = new FormControl();
    protected bossDestroy = new Subject<void>();
    public filteredBoss: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);
    public managerOptions: any[] = [];
    public managerSearch = new FormControl();
    protected managerDestroy = new Subject<void>();
    public filteredManager: ReplaySubject<any[]> = new ReplaySubject<any[]>(1);

    public formData = new FormData();

    constructor(
        private dialogRef: MatDialogRef<CreateEditComponent>,
        private timeService: TimeService,
        private formBuild: FormBuilder,
        private objToastrService: ToastrService,
        @Inject(MAT_DIALOG_DATA) private data: any
    ) {}

    ngOnInit() {
        this.title = this.data['title'];
        this.buildForm();
        this.searchChanged();
    }

    searchChanged() {
        this.managerSearch.valueChanges
            .pipe(takeUntil(this.managerDestroy))
            .subscribe(() => {
                this.filterManager();
            }
        );

        this.bossSearch.valueChanges
            .pipe(takeUntil(this.bossDestroy))
            .subscribe(() => {
                this.filterBoss();
            }
        );
    }

    filterBoss() {
        if (!this.bossOptions) {
            return;
        }

        let search = this.bossSearch.value;

        if (!search) {
            this.filteredBoss.next(this.bossOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredBoss.next(
            this.bossOptions.filter(option => option.name
                                        .toLowerCase()
                                        .indexOf(search) > -1)
        );
    }

    filterManager() {
        if (!this.managerOptions) {
            return;
        }

        let search = this.managerSearch.value;

        if (!search) {
            this.filteredManager.next(this.managerOptions.slice());
            return;
        } else {
            search = search.toLowerCase();
        }

        this.filteredManager.next(
            this.managerOptions.filter(option => option.name
                                        .toLowerCase()
                                        .indexOf(search) > -1)
        );
    }

    buildForm() {
        this.timesForm = this.formBuild.group({
            value: new FormControl('', Validators.required),
            description: new FormControl('', Validators.required),
        });

        this.setDataTime();
    }

    setDataTime() {
        if (this.data['time'] !== undefined) {
            this.timesForm.controls['value'].setValue(this.data['time'].value);
            this.timesForm.controls['description'].setValue(this.data['time'].description);
        }
    }

    save() {
        if (this.timesForm.invalid) {
            this.objToastrService.warning('Debe llenar todos los campos.', 'ALERTA:');
        } else {
            let time = this.timesForm.value;
            if (this.data['time'] !== undefined) {
                time = {
                    ...time,
                    id: this.data['time'].id
                };

                const timeData = {
                    time
                };
                this.timeService.update(timeData['time']).subscribe(
                    (resp) => {
                        if (resp.status === 200) {
                            this.dialogRef.close('ok');
                        } else {
                            this.objToastrService.error('Error guardando el tiempo', 'ERROR:');
                        }
                    }, () => {
                        this.objToastrService.error('Error guardando el tiempo', 'ERROR:');
                    }
                );
            } else {
                const timeData = {
                    time
                };

                this.timeService.add(timeData['time']).subscribe(
                    (resp) => {
                        if (resp.status === 200) {
                            this.dialogRef.close('ok');
                        } else {
                            this.objToastrService.error('Error guardando el tiempo', 'ERROR:');
                        }
                    }, () => {
                        this.objToastrService.error('Error guardando el tiempo', 'ERROR:');
                    }
                );
            }
        }
    }
}