import { Router } from '@angular/router';
import { ToastrService } from 'ngx-toastr';
import { TokenService } from '../../service/utils/token.service';
import { Component, OnInit } from "@angular/core";


declare interface RouteInfo {
  path: string;
  title: string;
  icon: string;
  class: string;
}
export const ROLE_ADMIN_ID = 1;
export const ROLE_AUDITOR_ID = 3;

export const ROUTES_AUDITOR: RouteInfo[] = [
  {
    path: "/home",
    title: "Inicio",
    icon: "icon-chart-pie-36",
    class: ""
  },
  {
    path: "/requests",
    title: "Crear solicitudes",
    icon: "icon-send",
    class: ""
  },
  {
    path: "/reportPage",
    title: "Reportes",
    icon: "icon-single-copy-04",
    class: ""
  },
  {
    path: "/users",
    title: "Usuarios",
    icon: "icon-single-02",
    class: ""
  },
  {
    path: "/uploads",
    title: "Cargas",
    icon: "icon-cloud-upload-94",
    class: ""
  },
  {
    path: '/states',
    title: 'Estados',
    icon: 'icon-align-left-2',
    class: ''
  },
  {
    path: '/categories',
    title: 'Categorías',
    icon: 'icon-components',
    class: ''
  },
  {
    path: '/subcategories',
    title: 'Subcategorías',
    icon: 'icon-vector',
    class: ''
  },
  {
    path: '/roles',
    title: 'Roles',
    icon: 'icon-badge',
    class: ''
  },
  {
    path: '/areas',
    title: 'Gerencias',
    icon: 'icon-bank',
    class:''
  },
  {
    path: '/times',
    title: 'Tiempos de respuesta',
    icon: 'icon-watch-time',
    class:''
  },
  {
    path: '/instructive',
    title: 'Ayuda',
    icon: 'icon-chat-33',
    class:''
  }
];

export const ROUTES_ADMIN: RouteInfo[] = [
  {
    path: "/home",
    title: "Inicio",
    icon: "icon-chart-pie-36",
    class: ""
  },
  {
    path: "/requests",
    title: "Crear solicitudes",
    icon: "icon-send",
    class: ""
  },
  {
    path: "/reportPage",
    title: "Reportes",
    icon: "icon-single-copy-04",
    class: ""
  },
  {
    path: "/users",
    title: "Usuarios",
    icon: "icon-single-02",
    class: ""
  },
  {
    path: "/uploads",
    title: "Cargas",
    icon: "icon-cloud-upload-94",
    class: ""
  },
  {
    path: '/states',
    title: 'Estados',
    icon: 'icon-align-left-2',
    class: ''
  },
  {
    path: '/categories',
    title: 'Categorías',
    icon: 'icon-components',
    class: ''
  },
  {
    path: '/subcategories',
    title: 'Subcategorías',
    icon: 'icon-vector',
    class: ''
  },
  {
    path: '/roles',
    title: 'Roles',
    icon: 'icon-badge',
    class: ''
  },
  {
    path: '/times',
    title: 'Tiempos de respuesta',
    icon: 'icon-watch-time',
    class:''
  },
  {
    path: '/instructive',
    title: 'Ayuda',
    icon: 'icon-chat-33',
    class:''
  }
];

export const ROUTES: RouteInfo[] = [
  {
    path: "/home",
    title: "Inicio",
    icon: "icon-world",
    class: ""
  },
  {
    path: "/requests",
    title: "Crear solicitudes",
    icon: "icon-send",
    class: ""
  },
  {
    path: '/instructive',
    title: 'Ayuda',
    icon: 'icon-chat-33',
    class:''
  }
];

@Component({
  selector: "app-sidebar",
  templateUrl: "./sidebar.component.html",
  styleUrls: ["./sidebar.component.css"]
})
export class SidebarComponent implements OnInit {
  menuItems: any[];

  constructor(
    private tokenService: TokenService,
    private objToastrService: ToastrService,
    private _router: Router
  ) {}

  ngOnInit() {
    this.tokenService.getDataUserFromToken().subscribe(
      (response: any) => {
        if (response.role_id === ROLE_ADMIN_ID) {
          this.menuItems = ROUTES_ADMIN.filter(menuItem => menuItem);
        } else if(response.role_id === ROLE_AUDITOR_ID) {
          this.menuItems = ROUTES_AUDITOR.filter(menuItem => menuItem);
        } else {
          this.menuItems = ROUTES.filter(menuItem => menuItem);
        }
      }, (error) => {
        this.objToastrService.error('La sesión ha expirado.', 'ERROR:');
        localStorage.removeItem('resourceToken');
        this._router.navigate(['/login']);
      }
    )

  }
  isMobileMenu() {
    if (window.innerWidth > 991) {
      return false;
    }
    return true;
  }
}
