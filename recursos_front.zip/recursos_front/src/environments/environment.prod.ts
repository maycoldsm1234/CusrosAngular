export const environment = {
  production: true,
  apiUrl: 'https://recursos.grupokonecta.local/api/'
};
